<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>UserCommandsSettings</name>
    <message>
        <source>Up</source>
        <translation>W górę</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>W dół</translation>
    </message>
    <message>
        <source>Hint</source>
        <translation>Wskazówka</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Ikona</translation>
    </message>
    <message>
        <source>G-code</source>
        <translation>G-code</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Remove all</source>
        <translation>Usuń wszystko</translation>
    </message>
</context>
<context>
    <name></name>
    <message>
        <source>User button</source>
        <translation>Przycisk użytkownika</translation>
    </message>
</context>
<context>
    <name>frmMain</name>
    <message>
        <source>User commands</source>
        <translation>Polecenia użytkownika</translation>
    </message>
</context>
</TS>
