<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>CoordinateSystem</name>
    <message>
        <source>Zero X</source>
        <translation>Zero X</translation>
    </message>
    <message>
        <source>Zero Y</source>
        <translation>Zero Y</translation>
    </message>
    <message>
        <source>Zero Z</source>
        <translation>Zero Z</translation>
    </message>
    <message>
        <source>Zero All</source>
        <translation>Zero All</translation>
    </message>
    <message>
        <source>Offsets:</source>
        <translation>Przesunięcia:</translation>
    </message>
</context>
<context>
    <name>frmMain</name>
    <message>
        <source>Coordinate system</source>
        <translation>System współrzędnych</translation>
    </message>
</context>
</TS>
