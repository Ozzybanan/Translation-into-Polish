<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>pluginCameraSettings</name>
    <message>
        <source>Name:</source>
        <translation>Nazwa:</translation>
    </message>
    <message>
        <source>Zoom:</source>
        <translation>Zoom:</translation>
    </message>
    <message>
        <source>Resolution:</source>
        <translation>Rozdzielczość:</translation>
    </message>
    <message>
        <source>Aim color:</source>
        <translation>Kolor celownika:</translation>
    </message>
    <message>
        <source>Aim line width:</source>
        <translation>Szerokość linii:</translation>
    </message>
    <message>
        <source>Position:</source>
        <translation>Pozycja:</translation>
    </message>
    <message>
        <source>Aim size:</source>
        <translation>Rozmiar celownika:</translation>
    </message>
    <message>
        <source>Aim position:</source>
        <translation>Pozycja celownika:</translation>
    </message>
</context>
<context>
    <name>frmMain</name>
    <message>
        <source>Camera</source>
        <translation>Kamera</translation>
    </message>
</context>
</TS>
