<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>QWidget</name>
    <message>
        <source>*</source>
        <translation>*</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>CD</source>
        <translation>CD</translation>
    </message>
    <message>
        <source>Go</source>
        <translation>Przejdź</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>W górę</translation>
    </message>
    <message>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <source>F%1</source>
        <translation>F%1</translation>
    </message>
    <message>
        <source>DOS</source>
        <translation>DOS</translation>
    </message>
    <message>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Wytnij</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Koniec</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Ins</source>
        <translation>Ins</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <source>Num</source>
        <translation>Num</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Czerwony</translation>
    </message>
    <message>
        <source>Tab</source>
        <translation>Tab</translation>
    </message>
    <message>
        <source>WWW</source>
        <translation>WWW</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Wstecz</translation>
    </message>
    <message>
        <source>Away</source>
        <translation>Away</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Niebieski</translation>
    </message>
    <message>
        <source>Book</source>
        <translation>Książka</translation>
    </message>
    <message>
        <source>Call</source>
        <translation>Zadzwoń</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <source>Ctrl</source>
        <translation>Ctrl</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>W dół</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Zakończ</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Znajdź</translation>
    </message>
    <message>
        <source>Flip</source>
        <translation>Powrót</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Gra</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Początek</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>W lewo</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <source>News</source>
        <translation>Aktualności</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Otwórz</translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation>PgUp</translation>
    </message>
    <message>
        <source>Play</source>
        <translation>Odtwórz</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Ponów</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Start</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Sklep</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Czas</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Cofnij</translation>
    </message>
    <message>
        <source>XFer</source>
        <translation>XFer</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Pogląd</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Split Screen</source>
        <translation>Podziel ekran</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Wyczyść</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>Eject</source>
        <translation>Wysuń</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Zielony</translation>
    </message>
    <message>
        <source>Guide</source>
        <translation>Przewodnik</translation>
    </message>
    <message>
        <source>Kanji</source>
        <translation>Kanji</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Muzyka</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Wklej</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pauza</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Telefon</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Drukuj</translation>
    </message>
    <message>
        <source>Reply</source>
        <translation>Odpowiedz</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>W prawo</translation>
    </message>
    <message>
        <source>Shift</source>
        <translation>Shift</translation>
    </message>
    <message>
        <source>Sleep</source>
        <translation>Uśpienie</translation>
    </message>
    <message>
        <source>Space</source>
        <translation>Spacja</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Narzędzia</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Hiragana</source>
        <translation>Hiragana</translation>
    </message>
    <message>
        <source>Wireless</source>
        <translation>Bezprzewodowy</translation>
    </message>
    <message>
        <source>Media Record</source>
        <translation>Rozpocznij nagrywanie</translation>
    </message>
    <message>
        <source>Media Rewind</source>
        <translation>Przewijanie mediów</translation>
    </message>
    <message>
        <source>Multiple Candidate</source>
        <translation>Kilka wariantów</translation>
    </message>
    <message>
        <source>Zenkaku</source>
        <translation>Zenkaku</translation>
    </message>
    <message>
        <source>Print Screen</source>
        <translation>Zrzut ekranu</translation>
    </message>
    <message>
        <source>Audio Rewind</source>
        <translation>Przewijanie dźwięku do tyłu</translation>
    </message>
    <message>
        <source>Audio Repeat</source>
        <translation>Powtarzanie dźwięku</translation>
    </message>
    <message>
        <source>Toggle Call/Hangup</source>
        <translation>Przełącz Połączenie/Rozłączenie</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Powiększ</translation>
    </message>
    <message>
        <source>Camera Shutter</source>
        <translation>Migawka aparatu</translation>
    </message>
    <message>
        <source>Ultra Wide Band</source>
        <translation>Ultraszerokie pasmo</translation>
    </message>
    <message>
        <source>Hangul Special</source>
        <translation>Hangul Special</translation>
    </message>
    <message>
        <source>Treble Down</source>
        <translation>Soprany w dół</translation>
    </message>
    <message>
        <source>Scroll Lock</source>
        <translation>Blokada przewijania</translation>
    </message>
    <message>
        <source>Media Pause</source>
        <translation>Pauza medialna</translation>
    </message>
    <message>
        <source>Word Processor</source>
        <translation>Edytor tekstu</translation>
    </message>
    <message>
        <source>Volume Down</source>
        <translation>Zmniejsz siłę głosu</translation>
    </message>
    <message>
        <source>Volume Mute</source>
        <translation>Wycisz głos</translation>
    </message>
    <message>
        <source>Kana Shift</source>
        <translation>Kana Shift</translation>
    </message>
    <message>
        <source>Media Previous</source>
        <translation>Poprzedni utwór</translation>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Strona główna</translation>
    </message>
    <message>
        <source>Meeting</source>
        <translation>Spotkanie</translation>
    </message>
    <message>
        <source>Touchpad Off</source>
        <translation>Wyłącz panel dotykowy</translation>
    </message>
    <message>
        <source>Volume Up</source>
        <translation>Zwiększ głośność</translation>
    </message>
    <message>
        <source>Menu PB</source>
        <translation>Menu PB</translation>
    </message>
    <message>
        <source>Keyboard Brightness Up</source>
        <translation>Zwiększ jasności klawiatury</translation>
    </message>
    <message>
        <source>Hangul PostHanja</source>
        <translation>Hangul PostHanja</translation>
    </message>
    <message>
        <source>Kana Lock</source>
        <translation>Kana Lock</translation>
    </message>
    <message>
        <source>Community</source>
        <translation>Społeczność</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Launch (6)</source>
        <translation>Uruchom (6)</translation>
    </message>
    <message>
        <source>Launch (7)</source>
        <translation>Uruchom (7)</translation>
    </message>
    <message>
        <source>Launch (8)</source>
        <translation>Uruchom (8)</translation>
    </message>
    <message>
        <source>Launch (9)</source>
        <translation>Uruchom (9)</translation>
    </message>
    <message>
        <source>Launch (2)</source>
        <translation>Uruchom (2)</translation>
    </message>
    <message>
        <source>Launch (3)</source>
        <translation>Uruchom (3)</translation>
    </message>
    <message>
        <source>Launch (4)</source>
        <translation>Uruchom (4)</translation>
    </message>
    <message>
        <source>Launch (5)</source>
        <translation>Uruchom (5)</translation>
    </message>
    <message>
        <source>Launch (0)</source>
        <translation>Uruchom (0)</translation>
    </message>
    <message>
        <source>Launch (1)</source>
        <translation>Uruchom (1)</translation>
    </message>
    <message>
        <source>Launch (F)</source>
        <translation>Uruchom (F)</translation>
    </message>
    <message>
        <source>Launch (B)</source>
        <translation>Uruchom (B)</translation>
    </message>
    <message>
        <source>Launch (C)</source>
        <translation>Uruchom (C)</translation>
    </message>
    <message>
        <source>Launch (D)</source>
        <translation>Uruchom (D)</translation>
    </message>
    <message>
        <source>Launch (E)</source>
        <translation>Uruchom (E)</translation>
    </message>
    <message>
        <source>Launch (A)</source>
        <translation>Uruchom (A)</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Delete</translation>
    </message>
    <message>
        <source>Escape</source>
        <translation>Escape</translation>
    </message>
    <message>
        <source>Audio Random Play</source>
        <translation>Odtwarzanie losowe audio</translation>
    </message>
    <message>
        <source>Hangul</source>
        <translation>Hangul</translation>
    </message>
    <message>
        <source>Hangup</source>
        <translation>Rozłącz</translation>
    </message>
    <message>
        <source>Henkan</source>
        <translation>Henkan</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Wstaw</translation>
    </message>
    <message>
        <source>Home Office</source>
        <translation>Biuro domowe</translation>
    </message>
    <message>
        <source>Last Number Redial</source>
        <translation>Wybieranie numeru ostatniego</translation>
    </message>
    <message>
        <source>Logoff</source>
        <translation>Wyloguj</translation>
    </message>
    <message>
        <source>Market</source>
        <translation>Market</translation>
    </message>
    <message>
        <source>Massyo</source>
        <translation>Massyo</translation>
    </message>
    <message>
        <source>Bass Boost</source>
        <translation>Podbicie basów</translation>
    </message>
    <message>
        <source>Channel Up</source>
        <translation>Kanał wyżej</translation>
    </message>
    <message>
        <source>Option</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation>PgDown</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Przeładuj</translation>
    </message>
    <message>
        <source>Return</source>
        <translation>Powrót</translation>
    </message>
    <message>
        <source>Romaji</source>
        <translation>Romaji</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Wybierz</translation>
    </message>
    <message>
        <source>SysReq</source>
        <translation>SysReq</translation>
    </message>
    <message>
        <source>Travel</source>
        <translation>Podróże</translation>
    </message>
    <message>
        <source>NumLock</source>
        <translation>NumLock</translation>
    </message>
    <message>
        <source>Audio Forward</source>
        <translation>Przewijanie dźwięku do przodu</translation>
    </message>
    <message>
        <source>WebCam</source>
        <translation>WebCam</translation>
    </message>
    <message>
        <source>Hiragana Katakana</source>
        <translation>Hiragana Katakana</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Żółty</translation>
    </message>
    <message>
        <source>Top Menu</source>
        <translation>Menu główne</translation>
    </message>
    <message>
        <source>ScrollLock</source>
        <translation>ScrollLock</translation>
    </message>
    <message>
        <source>Hot Links</source>
        <translation>Popularne łącza</translation>
    </message>
    <message>
        <source>Audio Cycle Track</source>
        <translation>Ścieżka cyklu audio</translation>
    </message>
    <message>
        <source>Context1</source>
        <translation>Kontekst1</translation>
    </message>
    <message>
        <source>Context2</source>
        <translation>Kontekst2</translation>
    </message>
    <message>
        <source>Context3</source>
        <translation>Kontekst3</translation>
    </message>
    <message>
        <source>Context4</source>
        <translation>Kontekst4</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Pomniejsz</translation>
    </message>
    <message>
        <source>Page Up</source>
        <translation>Strona w górę</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation>Otwórz URL</translation>
    </message>
    <message>
        <source>iTouch</source>
        <translation>iTouch</translation>
    </message>
    <message>
        <source>Previous Candidate</source>
        <translation>Poprzedni wariant</translation>
    </message>
    <message>
        <source>Toggle Media Play/Pause</source>
        <translation>Przełącz: Odtwarzanie/Pauza</translation>
    </message>
    <message>
        <source>Caps Lock</source>
        <translation>Caps Lock</translation>
    </message>
    <message>
        <source>Eisu Shift</source>
        <translation>Eisu Shift</translation>
    </message>
    <message>
        <source>Code input</source>
        <translation>Wpisz kod</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Drukarka</translation>
    </message>
    <message>
        <source>Camera Focus</source>
        <translation>Ostrość kamery</translation>
    </message>
    <message>
        <source>Adjust Brightness</source>
        <translation>Dostosuj jasność</translation>
    </message>
    <message>
        <source>Spreadsheet</source>
        <translation>Arkusz kalkulacyjny</translation>
    </message>
    <message>
        <source>Eisu toggle</source>
        <translation>Eisu przełącznik</translation>
    </message>
    <message>
        <source>Keyboard Brightness Down</source>
        <translation>Zmniejsz jasność klawiatury</translation>
    </message>
    <message>
        <source>Clear Grab</source>
        <translation>Usunąć uchwyt</translation>
    </message>
    <message>
        <source>Monitor Brightness Up</source>
        <translation>Zwiększ jasność monitora</translation>
    </message>
    <message>
        <source>System Request</source>
        <translation>Żądanie systemu</translation>
    </message>
    <message>
        <source>Microphone Volume Up</source>
        <translation>Zwiększ czułość mikrofonu</translation>
    </message>
    <message>
        <source>CapsLock</source>
        <translation>CapsLock</translation>
    </message>
    <message>
        <source>Backtab</source>
        <translation>Backtab</translation>
    </message>
    <message>
        <source>Bass Up</source>
        <translation>Podbić bas</translation>
    </message>
    <message>
        <source>Battery</source>
        <translation>Bateria</translation>
    </message>
    <message>
        <source>Katakana</source>
        <translation>Katakana</translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation>Odśwież</translation>
    </message>
    <message>
        <source>Hibernate</source>
        <translation>Hibernacja</translation>
    </message>
    <message>
        <source>Application Left</source>
        <translation>Lewy przycisk programowy</translation>
    </message>
    <message>
        <source>Voice Dial</source>
        <translation>Wybieranie głosowe</translation>
    </message>
    <message>
        <source>Browser</source>
        <translation>Przeglądarka</translation>
    </message>
    <message>
        <source>Keyboard Menu</source>
        <translation>Menu klawiatury</translation>
    </message>
    <message>
        <source>Back Forward</source>
        <translation>Dalej Wstecz</translation>
    </message>
    <message>
        <source>Launch Mail</source>
        <translation>Uruchom pocztę</translation>
    </message>
    <message>
        <source>Keyboard Light On/Off</source>
        <translation>Wł/Wył podświetlenie klawiatury</translation>
    </message>
    <message>
        <source>Backspace</source>
        <translation>Backspace</translation>
    </message>
    <message>
        <source>Bass Down</source>
        <translation>Zmniejsz bas</translation>
    </message>
    <message>
        <source>Mail Forward</source>
        <translation>Przekazywanie poczty</translation>
    </message>
    <message>
        <source>Messenger</source>
        <translation>Komunikator</translation>
    </message>
    <message>
        <source>Hangul Banja</source>
        <translation>Hangul Banja</translation>
    </message>
    <message>
        <source>Hangul Hanja</source>
        <translation>Hangul Hanja</translation>
    </message>
    <message>
        <source>Standby</source>
        <translation>Tryb czuwania</translation>
    </message>
    <message>
        <source>Hangul Start</source>
        <translation>Hangul Start</translation>
    </message>
    <message>
        <source>Rotation KB</source>
        <translation>Obrót KB</translation>
    </message>
    <message>
        <source>Rotation PB</source>
        <translation>Obrót PB</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Dokumenty</translation>
    </message>
    <message>
        <source>Calculator</source>
        <translation>Kalkulator</translation>
    </message>
    <message>
        <source>Support</source>
        <translation>Wsparcie</translation>
    </message>
    <message>
        <source>Suspend</source>
        <translation>Zawiesić</translation>
    </message>
    <message>
        <source>Display</source>
        <translation>Wyświetlacz</translation>
    </message>
    <message>
        <source>Hangul Romaja</source>
        <translation>Hangul Romaja</translation>
    </message>
    <message>
        <source>My Sites</source>
        <translation>Moje witryny</translation>
    </message>
    <message>
        <source>Rotate Windows</source>
        <translation>Obróć okna</translation>
    </message>
    <message>
        <source>Touroku</source>
        <translation>Touroku</translation>
    </message>
    <message>
        <source>Zenkaku Hankaku</source>
        <translation>Zenkaku Hankaku</translation>
    </message>
    <message>
        <source>Hangul Jeonja</source>
        <translation>Hangul Jeonja</translation>
    </message>
    <message>
        <source>Treble Up</source>
        <translation>Soprany w górę</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Napisy</translation>
    </message>
    <message>
        <source>Hangul Jamo</source>
        <translation>Hangul Jamo</translation>
    </message>
    <message>
        <source>Bluetooth</source>
        <translation>Bluetooth</translation>
    </message>
    <message>
        <source>Muhenkan</source>
        <translation>Muhenkan</translation>
    </message>
    <message>
        <source>Num Lock</source>
        <translation>Num Lock (blokada klawiatury)</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Wygaszacz ekranu</translation>
    </message>
    <message>
        <source>Number Lock</source>
        <translation>Blokada numerów</translation>
    </message>
    <message>
        <source>Power Down</source>
        <translation>Wyłącz zasilanie</translation>
    </message>
    <message>
        <source>Spellchecker</source>
        <translation>Sprawdzanie pisowni</translation>
    </message>
    <message>
        <source>Hangul PreHanja</source>
        <translation>Hangul PreHanja</translation>
    </message>
    <message>
        <source>Terminal</source>
        <translation>Terminal</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <source>Add Favorite</source>
        <translation>Dodaj ulubione</translation>
    </message>
    <message>
        <source>Execute</source>
        <translation>Wykonaj</translation>
    </message>
    <message>
        <source>Finance</source>
        <translation>Finanse</translation>
    </message>
    <message>
        <source>Microphone Volume Down</source>
        <translation>Zmniejsz czułość mikrofonu</translation>
    </message>
    <message>
        <source>Task Panel</source>
        <translation>Panel zadań</translation>
    </message>
    <message>
        <source>Favorites</source>
        <translation>Ulubione</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Naprzód</translation>
    </message>
    <message>
        <source>Page Down</source>
        <translation>Strona w dół</translation>
    </message>
    <message>
        <source>Wake Up</source>
        <translation>Przebudzenie</translation>
    </message>
    <message>
        <source>Power Off</source>
        <translation>Wyłącz</translation>
    </message>
    <message>
        <source>LightBulb</source>
        <translation>Żarówka</translation>
    </message>
    <message>
        <source>Touchpad Toggle</source>
        <translation>Przełącz panel dotykowy</translation>
    </message>
    <message>
        <source>Hankaku</source>
        <translation>Hankaku</translation>
    </message>
    <message>
        <source>Media Fast Forward</source>
        <translation>Szybkie przewijanie do przodu</translation>
    </message>
    <message>
        <source>Hangul End</source>
        <translation>Hangul End</translation>
    </message>
    <message>
        <source>Monitor Brightness Down</source>
        <translation>Zmniejsz jasność monitora</translation>
    </message>
    <message>
        <source>Microphone Mute</source>
        <translation>Wycisz mikrofon</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Historia</translation>
    </message>
    <message>
        <source>Media Play</source>
        <translation>Rozpocznij odtwarzanie</translation>
    </message>
    <message>
        <source>Media Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>Media Next</source>
        <translation>Następna ścieżka</translation>
    </message>
    <message>
        <source>Touchpad On</source>
        <translation>Włącz panel dotykowy</translation>
    </message>
    <message>
        <source>Channel Down</source>
        <translation>Kanał niżej</translation>
    </message>
    <message>
        <source>Launch Media</source>
        <translation>Uruchom media</translation>
    </message>
    <message>
        <source>Application Right</source>
        <translation>Prawy przycisk programowy</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Zdjęcia</translation>
    </message>
</context>
<context>
    <name>QPageSize</name>
    <message>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <source>B6</source>
        <translation>B6</translation>
    </message>
    <message>
        <source>B7</source>
        <translation>B7</translation>
    </message>
    <message>
        <source>B8</source>
        <translation>B8</translation>
    </message>
    <message>
        <source>B9</source>
        <translation>B9</translation>
    </message>
    <message>
        <source>A10</source>
        <translation>A10</translation>
    </message>
    <message>
        <source>B10</source>
        <translation>B10</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Note</translation>
    </message>
    <message>
        <source>Letter / ANSI A</source>
        <translation>List / ANSI A</translation>
    </message>
    <message>
        <source>Legal</source>
        <translation>Legal</translation>
    </message>
    <message>
        <source>Envelope Monarch</source>
        <translation>Koperta Monarch</translation>
    </message>
    <message>
        <source>Architect A</source>
        <translation>Architect A</translation>
    </message>
    <message>
        <source>Architect B</source>
        <translation>Architect B</translation>
    </message>
    <message>
        <source>Architect C</source>
        <translation>Architect C</translation>
    </message>
    <message>
        <source>Architect D</source>
        <translation>Architect D</translation>
    </message>
    <message>
        <source>Architect E</source>
        <translation>Architect E</translation>
    </message>
    <message>
        <source>Letter Extra</source>
        <translation>List Extra</translation>
    </message>
    <message>
        <source>Letter Small</source>
        <translation>List Small</translation>
    </message>
    <message>
        <source>Envelope You 4</source>
        <translation>Koperta You 4</translation>
    </message>
    <message>
        <source>Envelope US 10</source>
        <translation>Koperta US 10</translation>
    </message>
    <message>
        <source>Envelope US 11</source>
        <translation>Koperta US 11</translation>
    </message>
    <message>
        <source>Envelope US 12</source>
        <translation>Koperta US 12</translation>
    </message>
    <message>
        <source>Envelope US 14</source>
        <translation>Koperta US 14</translation>
    </message>
    <message>
        <source>Envelope PRC 1</source>
        <translation>Kopertae PRC 1</translation>
    </message>
    <message>
        <source>Envelope PRC 2</source>
        <translation>Koperta PRC 2</translation>
    </message>
    <message>
        <source>Envelope PRC 3</source>
        <translation>Koperta PRC 3</translation>
    </message>
    <message>
        <source>Envelope PRC 4</source>
        <translation>Koperta PRC 4</translation>
    </message>
    <message>
        <source>Envelope PRC 5</source>
        <translation>Koperta PRC 5</translation>
    </message>
    <message>
        <source>Envelope PRC 6</source>
        <translation>Koperta PRC 6</translation>
    </message>
    <message>
        <source>Envelope PRC 7</source>
        <translation>Koperta PRC 7</translation>
    </message>
    <message>
        <source>Envelope PRC 8</source>
        <translation>Koperta PRC 8</translation>
    </message>
    <message>
        <source>Envelope PRC 9</source>
        <translation>Koperta PRC 9</translation>
    </message>
    <message>
        <source>Envelope C65</source>
        <translation>Koperta C65</translation>
    </message>
    <message>
        <source>Envelope DL</source>
        <translation>Koperta DL</translation>
    </message>
    <message>
        <source>Envelope B4</source>
        <translation>Koperta B4</translation>
    </message>
    <message>
        <source>Envelope B5</source>
        <translation>Koperta B5</translation>
    </message>
    <message>
        <source>Envelope B6</source>
        <translation>Koperta B6</translation>
    </message>
    <message>
        <source>Envelope C0</source>
        <translation>Koperta C0</translation>
    </message>
    <message>
        <source>Envelope C1</source>
        <translation>Koperta C1</translation>
    </message>
    <message>
        <source>Envelope C2</source>
        <translation>Koperta C2</translation>
    </message>
    <message>
        <source>Envelope C3</source>
        <translation>Koperta C3</translation>
    </message>
    <message>
        <source>Envelope C4</source>
        <translation>Koperta C4</translation>
    </message>
    <message>
        <source>Envelope C5</source>
        <translation>Koperta C5</translation>
    </message>
    <message>
        <source>Envelope C6</source>
        <translation>Koperta C6</translation>
    </message>
    <message>
        <source>Envelope C7</source>
        <translation>Koperta C7</translation>
    </message>
    <message>
        <source>Executive (7.5 x 10 in)</source>
        <translation>Executive (7.5 x 10 in)</translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation>ANSI C</translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation>ANSI D</translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation>ANSI E</translation>
    </message>
    <message>
        <source>A4 Plus</source>
        <translation>A4 Plus</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Niestandardowy</translation>
    </message>
    <message>
        <source>JIS B0</source>
        <translation>JIS B0</translation>
    </message>
    <message>
        <source>JIS B1</source>
        <translation>JIS B1</translation>
    </message>
    <message>
        <source>JIS B2</source>
        <translation>JIS B2</translation>
    </message>
    <message>
        <source>JIS B3</source>
        <translation>JIS B3</translation>
    </message>
    <message>
        <source>JIS B4</source>
        <translation>JIS B4</translation>
    </message>
    <message>
        <source>JIS B5</source>
        <translation>JIS B5</translation>
    </message>
    <message>
        <source>JIS B6</source>
        <translation>JIS B6</translation>
    </message>
    <message>
        <source>JIS B7</source>
        <translation>JIS B7</translation>
    </message>
    <message>
        <source>JIS B8</source>
        <translation>JIS B8</translation>
    </message>
    <message>
        <source>JIS B9</source>
        <translation>JIS B9</translation>
    </message>
    <message>
        <source>A3 Extra</source>
        <translation>A3 Extra</translation>
    </message>
    <message>
        <source>PRC 16K</source>
        <translation>PRC 16K</translation>
    </message>
    <message>
        <source>PRC 32K</source>
        <translation>PRC 32K</translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation>Quarto</translation>
    </message>
    <message>
        <source>PRC 32K Big</source>
        <translation>PRC 32K Big</translation>
    </message>
    <message>
        <source>A4 Extra</source>
        <translation>A4 Extra</translation>
    </message>
    <message>
        <source>A4 Small</source>
        <translation>A4 Small</translation>
    </message>
    <message>
        <source>Executive (7.25 x 10.5 in)</source>
        <translation>Executive (7.25 x 10.5 in)</translation>
    </message>
    <message>
        <source>Postcard</source>
        <translation>Pocztówka</translation>
    </message>
    <message>
        <source>Tabloid / ANSI B</source>
        <translation>Tabloid / ANSI B</translation>
    </message>
    <message>
        <source>A5 Extra</source>
        <translation>A5 Extra</translation>
    </message>
    <message>
        <source>B5 Extra</source>
        <translation>B5 Extra</translation>
    </message>
    <message>
        <source>Envelope Invite</source>
        <translation>Koperta - Zaproszenie</translation>
    </message>
    <message>
        <source>Envelope Chou 3</source>
        <translation>Koperta Chou 3</translation>
    </message>
    <message>
        <source>Envelope Chou 4</source>
        <translation>Koperta Chou 4</translation>
    </message>
    <message>
        <source>Statement</source>
        <translation>Komunikat</translation>
    </message>
    <message>
        <source>Fan-fold German (8.5 x 12 in)</source>
        <translation>Fan-fold German (8.5 x 12 in)</translation>
    </message>
    <message>
        <source>Envelope PRC 10</source>
        <translation>Koperta PRC 10</translation>
    </message>
    <message>
        <source>Envelope Kaku 2</source>
        <translation>Koperta Kaku 2</translation>
    </message>
    <message>
        <source>Envelope Kaku 3</source>
        <translation>Koperta Kaku 3</translation>
    </message>
    <message>
        <source>Envelope US 9</source>
        <translation>Koperta US 9</translation>
    </message>
    <message>
        <source>%1 x %2 in</source>
        <translation>%1 x %2 po</translation>
    </message>
    <message>
        <source>Super A</source>
        <translation>Super A</translation>
    </message>
    <message>
        <source>Super B</source>
        <translation>Super B</translation>
    </message>
    <message>
        <source>Fan-fold US (14.875 x 11 in)</source>
        <translation>Fan-fold US (14.875 x 11 in)</translation>
    </message>
    <message>
        <source>Fan-fold German Legal (8.5 x 13 in)</source>
        <translation>Fan-fold German Legal (8.5 x 13 in)</translation>
    </message>
    <message>
        <source>Custom (%1in x %2in)</source>
        <translation>Niestandardowy (%1in x %2in)</translation>
    </message>
    <message>
        <source>Custom (%1mm x %2mm)</source>
        <translation>Niestandardowy (%1mm x %2mm)</translation>
    </message>
    <message>
        <source>Custom (%1CC x %2CC)</source>
        <translation>Niestandardowy (%1CC x %2CC)</translation>
    </message>
    <message>
        <source>Custom (%1DD x %2DD)</source>
        <translation>Niestandardowy (%1DD x %2DD)</translation>
    </message>
    <message>
        <source>Custom (%1pc x %2pc)</source>
        <translation>Niestandardowy (%1pc  %2pc)</translation>
    </message>
    <message>
        <source>Custom (%1pt x %2pt)</source>
        <translation>Niestandardowy (%1pkt x %2pkt)</translation>
    </message>
    <message>
        <source>Letter Plus</source>
        <translation>List Plus</translation>
    </message>
    <message>
        <source>Tabloid Extra</source>
        <translation>Tabloid Extra</translation>
    </message>
    <message>
        <source>Envelope Italian</source>
        <translation>Koperta Italian</translation>
    </message>
    <message>
        <source>Double Postcard</source>
        <translation>Podwójna pocztówka</translation>
    </message>
    <message>
        <source>Legal Extra</source>
        <translation>Legal Extra</translation>
    </message>
    <message>
        <source>Folio (8.27 x 13 in)</source>
        <translation>Folio (8.27 x 13 in)</translation>
    </message>
    <message>
        <source>Ledger / ANSI B</source>
        <translation>Ledger / ANSI B</translation>
    </message>
    <message>
        <source>JIS B10</source>
        <translation>JIS B10</translation>
    </message>
    <message>
        <source>Envelope Personal</source>
        <translation>Koperta osobista</translation>
    </message>
</context>
<context>
    <name>QPrintDialog</name>
    <message>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <source>B6</source>
        <translation>B6</translation>
    </message>
    <message>
        <source>B7</source>
        <translation>B7</translation>
    </message>
    <message>
        <source>B8</source>
        <translation>B8</translation>
    </message>
    <message>
        <source>B9</source>
        <translation>B9</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>B10</source>
        <translation>B10</translation>
    </message>
    <message>
        <source>C5E</source>
        <translation>C5E</translation>
    </message>
    <message>
        <source>DLE</source>
        <translation>DLE</translation>
    </message>
    <message>
        <source>Folio</source>
        <translation>Foglio</translation>
    </message>
    <message>
        <source>Even Pages</source>
        <translation>Parzyste strony</translation>
    </message>
    <message>
        <source>Legal</source>
        <translation>Legal</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Drukuj</translation>
    </message>
    <message>
        <source>&amp;Options &lt;&lt;</source>
        <translation>&amp;Opcje &lt;&lt;</translation>
    </message>
    <message>
        <source>&amp;Options &gt;&gt;</source>
        <translation>&amp;Opcje &lt;&lt;</translation>
    </message>
    <message>
        <source>Left to Right, Top to Bottom</source>
        <translation>Od lewej do prawej, od góry do dołu</translation>
    </message>
    <message>
        <source>Right to Left, Bottom to Top</source>
        <translation>Od prawej do lewej, od dołu do góry</translation>
    </message>
    <message>
        <source>Write PDF file</source>
        <translation>Zapisz plik PDF</translation>
    </message>
    <message>
        <source>&amp;Print</source>
        <translation>&amp;Drukuj</translation>
    </message>
    <message>
        <source>1 (1x1)</source>
        <translation>1 (1x1)</translation>
    </message>
    <message>
        <source>Options &apos;Pages Per Sheet&apos; and &apos;Page Set&apos; cannot be used together.
Please turn one of those options off.</source>
        <translation>Opcji „Stron na arkusz” i „Zestaw stron” nie można używać razem.
Wyłącz jedną z tych opcji.</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to overwrite it?</source>
        <translation>%1 już istnieje.
Czy chcesz to nadpisać?</translation>
    </message>
    <message>
        <source>2 (2x1)</source>
        <translation>2 (2x1)</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Niestandardowy</translation>
    </message>
    <message>
        <source>Ledger</source>
        <translation>Ledger</translation>
    </message>
    <message>
        <source>Letter</source>
        <translation>List</translation>
    </message>
    <message>
        <source>Left to Right, Bottom to Top</source>
        <translation>Od lewej do prawej, od dołu do góry</translation>
    </message>
    <message>
        <source>4 (2x2)</source>
        <translation>4 (2x2)</translation>
    </message>
    <message>
        <source>Odd Pages</source>
        <translation>Strony nieparzyste</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Plik lokalny</translation>
    </message>
    <message>
        <source>6 (2x3)</source>
        <translation>6 (2x3)</translation>
    </message>
    <message>
        <source>16 (4x4)</source>
        <translation>16 (4x4)</translation>
    </message>
    <message>
        <source>Print to File (PDF)</source>
        <translation>Drukuj do pliku (PDF)</translation>
    </message>
    <message>
        <source>Print To File ...</source>
        <translation>Drukuj do pliku ...</translation>
    </message>
    <message>
        <source>Tabloid</source>
        <translation>Tabloid</translation>
    </message>
    <message>
        <source>9 (3x3)</source>
        <translation>9 (3x3)</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automatyczny</translation>
    </message>
    <message>
        <source>Executive</source>
        <translation>Executive</translation>
    </message>
    <message>
        <source>Right to Left, Top to Bottom</source>
        <translation>Od prawej do lewej, od góry do dołu</translation>
    </message>
    <message>
        <source>Bottom to Top, Left to Right</source>
        <translation>Od dołu do góry, od lewej do prawej</translation>
    </message>
    <message>
        <source>The &apos;From&apos; value cannot be greater than the &apos;To&apos; value.</source>
        <translation>Wartość „Od” nie może być większa niż wartość „Do”.</translation>
    </message>
    <message>
        <source>US Common #10 Envelope</source>
        <translation>Koperta US Common # 10</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Wszystkie strony</translation>
    </message>
    <message>
        <source>%1 is a directory.
Please choose a different file name.</source>
        <translation>%1 to katalog.
Wybierz inną nazwę pliku.</translation>
    </message>
    <message>
        <source>File %1 is not writable.
Please choose a different file name.</source>
        <translation>Plik %1 nie jest zapisywalny.
Wybierz inną nazwę pliku.</translation>
    </message>
    <message>
        <source>Bottom to Top, Right to Left</source>
        <translation>Od dołu do góry, od prawej do lewej</translation>
    </message>
    <message>
        <source>Top to Bottom, Left to Right</source>
        <translation>Od góry do dołu, od lewej do prawej</translation>
    </message>
    <message>
        <source>Top to Bottom, Right to Left</source>
        <translation>Od góry do dołu, od prawej do lewej</translation>
    </message>
</context>
<context>
    <name>QDateTimeEdit</name>
    <message>
        <source>AM</source>
        <translation>AM</translation>
    </message>
    <message>
        <source>PM</source>
        <translation>PM</translation>
    </message>
    <message>
        <source>am</source>
        <translation>am</translation>
    </message>
    <message>
        <source>pm</source>
        <translation>pm</translation>
    </message>
</context>
<context>
    <name>QDateTimeParser</name>
    <message>
        <source>AM</source>
        <translation>לפני הצהריים</translation>
    </message>
    <message>
        <source>PM</source>
        <translation>אחרי הצהריים</translation>
    </message>
    <message>
        <source>am</source>
        <translation>לפני הצהריים</translation>
    </message>
    <message>
        <source>pm</source>
        <translation>אחרי הצהריים</translation>
    </message>
</context>
<context>
    <name>QPageSetupWidget</name>
    <message>
        <source>CC</source>
        <translation>CC</translation>
    </message>
    <message>
        <source>DD</source>
        <translation>DD</translation>
    </message>
    <message>
        <source>in</source>
        <translation>in</translation>
    </message>
    <message>
        <source>mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <source>pt</source>
        <translation>pkt</translation>
    </message>
    <message>
        <source>P̸</source>
        <translation>P̸</translation>
    </message>
    <message>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <source>bottom margin</source>
        <translation>dolny margines</translation>
    </message>
    <message>
        <source>Paper</source>
        <translation>Papier</translation>
    </message>
    <message>
        <source>Paper source:</source>
        <translation>Źródło papieru:</translation>
    </message>
    <message>
        <source>Centimeters (cm)</source>
        <translation>Centymetry (cm)</translation>
    </message>
    <message>
        <source>right margin</source>
        <translation>prawy margines</translation>
    </message>
    <message>
        <source>Pica (P̸)</source>
        <translation>Pica (P̸)</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation>Marginesy</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Niestandardowy</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Poziomo</translation>
    </message>
    <message>
        <source>Page Layout</source>
        <translation>Układ strony</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Szerokość:</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Orientacja</translation>
    </message>
    <message>
        <source>Didot (DD)</source>
        <translation>Didot (DD)</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Pionowo</translation>
    </message>
    <message>
        <source>Page order:</source>
        <translation>Kolejność stron:</translation>
    </message>
    <message>
        <source>top margin</source>
        <translation>górny margines</translation>
    </message>
    <message>
        <source>left margin</source>
        <translation>lewy margines</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Rozmiar strony:</translation>
    </message>
    <message>
        <source>Cicero (CC)</source>
        <translation>Cicero (CC)</translation>
    </message>
    <message>
        <source>Reverse portrait</source>
        <translation>Odwrócić pionowo</translation>
    </message>
    <message>
        <source>Millimeters (mm)</source>
        <translation>Milimetry (mm)</translation>
    </message>
    <message>
        <source>Points (pt)</source>
        <translation>Punkty (pkt)</translation>
    </message>
    <message>
        <source>Pages per sheet:</source>
        <translation>Stron na jednym arkuszu:</translation>
    </message>
    <message>
        <source>Inches (in)</source>
        <translation>Cale (in)</translation>
    </message>
    <message>
        <source>Reverse landscape</source>
        <translation>Odwróć poziomo</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Wysokość:</translation>
    </message>
</context>
<context>
    <name>QAxSelect</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>COM &amp;Object:</source>
        <translation>&amp;Obiekt COM:</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
    <message>
        <source>Select ActiveX Control</source>
        <translation>Wybierz ActiveX Control</translation>
    </message>
</context>
<context>
    <name>QDBusTrayIcon</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>QDialogButtonBox</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nie</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Tak</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Otwórz</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Zapisz</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Przerwij</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Zastosuj</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Ponów</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Przywróć domyślne</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Zamknij</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignoruj</translation>
    </message>
    <message>
        <source>Close without Saving</source>
        <translation>Zamknij bez zapisywania</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>N&amp;ie dla wszystkich</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Zapisz wszystko</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odrzuć</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>T&amp;ak dla wszystkich</translation>
    </message>
    <message>
        <source>Don&apos;t Save</source>
        <translation>Nie zapisuj</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <source>Show Details...</source>
        <translation>Pokaż szczegóły...</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under three different licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of the GNU LGPL version 3 or GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 3 is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the GNU LGPL version 3.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 2.1 is appropriate for the development of Qt&amp;nbsp;applications provided you can comply with the terms and conditions of the GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) %1 The Qt Company Ltd and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Qt is The Qt Company Ltd product developed as an open source project. See &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Qt jest zestawem narzędzi C++ do tworzenia aplikacji wieloplatformowych.&lt;/p&gt;&lt;p&gt;Qt zapewnia możliwość przenoszenia z jednego źródła na wszystkie główne systemy operacyjne. Jest również dostępny dla wbudowanego systemu Linux oraz innych wbudowanych i mobilnych systemów operacyjnych.&lt;/p&gt;&lt;p&gt;Qt jest dostępny w trzech różnych opcjach licencjonowania zaprojektowanych tak, aby zaspokoić potrzeby naszych różnych użytkowników.&lt;/p&gt;&lt;p&gt;Qt licencjonowany na naszej komercyjnej umowie licencyjnej jest odpowiedni do tworzenia oprogramowania własnościowego/komercyjnego, gdzie nie chcesz udostępniać kodu źródłowego osobom trzecim lub w inny sposób nie możesz spełnić warunków licencji GNU LGPL wersja 3 lub GNU LGPL wersja 2.1. &lt;/p&gt;&lt;p&gt;Qt na licencji GNU LGPL w wersji 3 jest odpowiedni do tworzenia Qt&amp;nbsp;aplikacji pod warunkiem, że możesz spełnić warunki licencji GNU LGPL w wersji 3.&lt;/p&gt;&lt;p&gt;Qt na licencji GNU LGPL w wersji 2.1 jest odpowiedni do tworzenia Qt&amp;nbsp;aplikacji pod warunkiem, że możesz spełnić warunki licencji GNU LGPL w wersji 2. 1.&lt;/p&gt;&lt;p&gt;Zobacz &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt;w celu zapoznania się z licencjonowaniem Qt.&lt;/p&gt;&lt;p&gt;Copyright (C) %1 The Qt Company Ltd i inni współautorzy.&lt;/p&gt;&lt;p&gt;Qt i logo Qt są znakami towarowymi The Qt Company Ltd.&lt;/p&gt;&lt;p&gt;Qt jest produktem The Qt Company Ltd rozwijanym jako projekt open source. Zobacz &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt;, aby uzyskać więcej informacji.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under three different licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of the GNU LGPL version 2.1 or GNU GPL version 3.0.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 2.1 is appropriate for the development of Qt applications provided you can comply with the terms and conditions of the GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU General Public License version 3.0 is appropriate for the development of Qt applications where you wish to use such applications in combination with software subject to the terms of the GNU GPL version 3.0 or where you are otherwise willing to comply with the terms of the GNU GPL version 3.0.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://qt.io/licensing/&quot;&gt;qt.io/licensing&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) 2015 The Qt Company Ltd and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of Digia Plc and/or its subsidiary(-ies).&lt;/p&gt;&lt;p&gt;Qt is developed as an open source project on &lt;a href=&quot;http://qt-project.org/&quot;&gt;qt-project.org&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Qt is a Digia product. See &lt;a href=&quot;http://qt.io/&quot;&gt;qt.io&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Qt jest zestawem narzędzi C++ do tworzenia aplikacji wieloplatformowych.&lt;/p&gt;&lt;p&gt;Qt zapewnia możliwość przenoszenia z jednego źródła na wszystkie główne systemy operacyjne. Jest również dostępny dla wbudowanego systemu Linux oraz innych wbudowanych i mobilnych systemów operacyjnych.&lt;/p&gt;&lt;p&gt;Qt jest dostępny w trzech różnych opcjach licencyjnych zaprojektowanych tak, aby zaspokoić potrzeby naszych różnych użytkowników.&lt;/p&gt;&lt;p&gt;Qt licencjonowany w ramach naszej komercyjnej umowy licencyjnej jest odpowiedni do tworzenia własnościowego/komercyjnego oprogramowania, gdzie nie chcesz udostępniać kodu źródłowego osobom trzecim lub w inny sposób nie możesz spełnić warunków licencji GNU LGPL wersja 2. 1 lub GNU GPL w wersji 3.0.&lt;/p&gt;&lt;p&gt;Qt na licencji GNU LGPL w wersji 2.1 jest odpowiednia do tworzenia aplikacji Qt pod warunkiem, że mogą Państwo przestrzegać warunków licencji GNU LGPL w wersji 2.1. &lt;/p&gt;&lt;p&gt;Qt na licencji GNU General Public License w wersji 3.0 jest odpowiedni do tworzenia aplikacji Qt, jeżeli chcą Państwo używać takich aplikacji w połączeniu z oprogramowaniem podlegającym warunkom GNU GPL w wersji 3.0 lub jeżeli są Państwo w inny sposób gotowi przestrzegać warunków GNU GPL w wersji 3.0.&lt;/p&gt;&lt;p&gt;Zapraszamy do zapoznania się z &lt;a href=&quot;http://qt. io/licensing/&quot;&gt;qt.io/licensing&lt;/a&gt; w celu zapoznania się z licencjonowaniem Qt.&lt;/p&gt;&lt;p&gt;Copyright (C) 2015 The Qt Company Ltd i inni współtwórcy. &lt;/p&gt;&lt;p&gt;Qt i logo Qt są znakami towarowymi firmy Digia Plc i/lub jej spółek zależnych.&lt;/p&gt;&lt;p&gt;Qt jest rozwijany jako projekt open source na stronie &lt;a href=&quot;http://qt-project.org/&quot;&gt;qt-project.org&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Qt jest produktem firmy Digia. Więcej informacji można znaleźć na stronie &lt;a href=&quot;http://qt.io/&quot;&gt;qt.io&lt;/a&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under three different licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of the GNU LGPL version 3 or GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 3 is appropriate for the development of Qt applications provided you can comply with the terms and conditions of the GNU LGPL version 3.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 2.1 is appropriate for the development of Qt applications provided you can comply with the terms and conditions of the GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) %1 Digia Plc and/or its subsidiary(-ies) and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of Digia Plc and/or its subsidiary(-ies).&lt;/p&gt;&lt;p&gt;Qt is a Digia product developed as an open source project. See &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Qt jest zestawem narzędzi C++ do tworzenia aplikacji wieloplatformowych.&lt;/p&gt;&lt;p&gt;Qt zapewnia możliwość przenoszenia z jednego źródła do wszystkich głównych systemów operacyjnych. Jest również dostępny dla wbudowanego systemu Linux oraz innych wbudowanych i mobilnych systemów operacyjnych.&lt;/p&gt;&lt;p&gt;Qt jest dostępny w trzech różnych opcjach licencjonowania, zaprojektowanych w celu zaspokojenia potrzeb naszych różnych użytkowników. &lt;/p&gt;&lt;p&gt;Qt na licencji komercyjnej jest odpowiedni do tworzenia oprogramowania własnościowego/komercyjnego, w przypadku gdy nie chcesz udostępniać kodu źródłowego osobom trzecim lub nie możesz spełnić warunków licencji GNU LGPL w wersji 3 lub GNU LGPL w wersji 2.1.&lt;/p&gt;&lt;p&gt;Qt na licencji GNU LGPL w wersji 3 jest odpowiedni do tworzenia aplikacji Qt pod warunkiem, że możesz spełnić warunki licencji GNU LGPL w wersji 3. &lt;/p&gt;&lt;p&gt;Qt na licencji GNU LGPL w wersji 2.1 jest odpowiedni do tworzenia aplikacji Qt pod warunkiem, że spełniasz warunki licencji GNU LGPL w wersji 2.1.&lt;/p&gt;&lt;p&gt;Zapoznaj się z &lt;a href=&quot;http://%2/&quot;&gt;%2&lt;/a&gt; w celu zapoznania się z licencjonowaniem Qt. &lt;/p&gt;&lt;p&gt;Copyright (C) %1 Digia Plc and/or its subsidiary(-ies) and other contributors.&lt;/p&gt;&lt;p&gt;Qt i logo Qt są znakami towarowymi firmy Digia Plc i/lub jej spółek zależnych.&lt;/p&gt;&lt;p&gt;Qt jest produktem firmy Digia rozwijanym jako projekt open source. Zobacz &lt;a href=&quot;http://%3/&quot;&gt;%3&lt;/a&gt; aby uzyskać więcej informacji.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Info o Qt</translation>
    </message>
    <message>
        <source>Hide Details...</source>
        <translation>Ukryj szczegóły...</translation>
    </message>
    <message>
        <source>&lt;h3&gt;About Qt&lt;/h3&gt;&lt;p&gt;This program uses Qt version %1.&lt;/p&gt;</source>
        <translation>&lt;h3&gt;Informacje o Qt&lt;/h3&gt;&lt;p&gt;Ta program używa wersji Qt %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across all major desktop operating systems. It is also available for embedded Linux and other embedded and mobile operating systems.&lt;/p&gt;&lt;p&gt;Qt is available under three different licensing options designed to accommodate the needs of our various users.&lt;/p&gt;&lt;p&gt;Qt licensed under our commercial license agreement is appropriate for development of proprietary/commercial software where you do not want to share any source code with third parties or otherwise cannot comply with the terms of the GNU LGPL version 2.1 or GNU GPL version 3.0.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU LGPL version 2.1 is appropriate for the development of Qt applications provided you can comply with the terms and conditions of the GNU LGPL version 2.1.&lt;/p&gt;&lt;p&gt;Qt licensed under the GNU General Public License version 3.0 is appropriate for the development of Qt 
applications where you wish to use such applications in combination with software subject to the terms of the GNU GPL version 3.0 or where you are otherwise willing to comply with the terms of the GNU GPL version 3.0.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://qt.io/licensing/&quot;&gt;qt.io/licensing&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;&lt;p&gt;Copyright (C) 2015 The Qt Company Ltd and other contributors.&lt;/p&gt;&lt;p&gt;Qt and the Qt logo are trademarks of Digia Plc and/or its subsidiary(-ies).&lt;/p&gt;&lt;p&gt;Qt is developed as an open source project on &lt;a href=&quot;http://qt-project.org/&quot;&gt;qt-project.org&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Qt is a Digia product. See &lt;a href=&quot;http://qt.io/&quot;&gt;qt.io&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Qt jest zestawem narzędzi C++ do tworzenia aplikacji wieloplatformowych.&lt;/p&gt;&lt;p&gt;Qt zapewnia możliwość przenoszenia z jednego źródła na wszystkie główne systemy operacyjne. Jest również dostępny dla wbudowanego systemu Linux oraz innych wbudowanych i mobilnych systemów operacyjnych.&lt;/p&gt;&lt;p&gt;Qt jest dostępny w trzech różnych opcjach licencyjnych zaprojektowanych tak, aby zaspokoić potrzeby naszych różnych użytkowników.&lt;/p&gt;&lt;p&gt;Qt licencjonowany w ramach naszej komercyjnej umowy licencyjnej jest odpowiedni do tworzenia własnościowego/komercyjnego oprogramowania, gdzie nie chcesz udostępniać kodu źródłowego osobom trzecim lub w inny sposób nie możesz spełnić warunków licencji GNU LGPL wersja 2. 1 lub GNU GPL w wersji 3.0.&lt;/p&gt;&lt;p&gt;Qt na licencji GNU LGPL w wersji 2.1 jest odpowiedni do tworzenia aplikacji Qt, pod warunkiem, że można spełnić warunki licencji GNU LGPL w wersji 2.1.&lt;/p&gt;&lt;p&gt;Qt na licencji GNU General Public License w wersji 3.0 jest odpowiedni do tworzenia aplikacji Qt, jeżeli chcą Państwo korzystać z takich aplikacji. 
gdy chcesz używać takich aplikacji w połączeniu z oprogramowaniem podlegającym warunkom GNU GPL w wersji 3.0 lub gdy w inny sposób chcesz przestrzegać warunków GNU GPL w wersji 3.0.&lt;/p&gt;&lt;p&gt;Zapoznaj się z &lt;a href=&quot;http://qt.io/licensing/&quot;&gt;qt.io/licensing&lt;/a&gt; w celu zapoznania się z licencjonowaniem Qt. &lt;/p&gt;&lt;p&gt;Copyright (C) 2015 The Qt Company Ltd and other contributors.&lt;/p&gt;&lt;p&gt;Qt i logo Qt są znakami towarowymi firmy Digia Plc i/lub jej spółek zależnych.&lt;/p&gt;&lt;p&gt;Qt jest rozwijany jako projekt open source na stronie &lt;a href=&quot;http://qt-project.org/&quot;&gt;qt-project.org&lt;/a&gt;.&lt;/p&gt;&lt;p&gt;Qt jest produktem firmy Digia. Więcej informacji można znaleźć na stronie &lt;a href=&quot;http://qt.io/&quot;&gt;qt.io&lt;/a&gt;.&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>QPlatformTheme</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nie</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Tak</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Otwórz</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Przerwij</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Zastosuj</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Ponów</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Przywróć domyślne</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignoruj</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>N&amp;ie dla wszystkich</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Zapisz wszystko</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odrzuć</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>T&amp;ak dla wszystkich</translation>
    </message>
</context>
<context>
    <name>QQnxFileDialogHelper</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>CANCEL</source>
        <translation>ANULUJ</translation>
    </message>
    <message>
        <source>All files (*.*)</source>
        <translation>Wszystkie pliki (*.*)</translation>
    </message>
</context>
<context>
    <name>QtAndroidDialogHelpers::QAndroidPlatformMessageDialogHelper</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Otwórz</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Przerwij</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Zastosuj</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Ponów</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Przywróć domyślne</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignoruj</translation>
    </message>
    <message>
        <source>No to All</source>
        <translation>Nie dla wszystkich</translation>
    </message>
    <message>
        <source>Yes to All</source>
        <translation>Tak dla wszystkich</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Zapisz wszystko</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odrzuć</translation>
    </message>
</context>
<context>
    <name>QAndroidPlatformTheme</name>
    <message>
        <source>No</source>
        <translation>Nie</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <source>No to All</source>
        <translation>Nie dla wszystkich</translation>
    </message>
    <message>
        <source>Yes to All</source>
        <translation>Tak dla wszystkich</translation>
    </message>
</context>
<context>
    <name>QPrintSettingsOutput</name>
    <message>
        <source>to</source>
        <translation>do</translation>
    </message>
    <message>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Żaden</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Kolor</translation>
    </message>
    <message>
        <source>Print all</source>
        <translation>Drukuj wszystko</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Bieżąca strona</translation>
    </message>
    <message>
        <source>Selection</source>
        <translation>Wybór</translation>
    </message>
    <message>
        <source>Long side</source>
        <translation>Długa strona</translation>
    </message>
    <message>
        <source>Copies</source>
        <translation>Kopie</translation>
    </message>
    <message>
        <source>Print range</source>
        <translation>Zakres wydruku</translation>
    </message>
    <message>
        <source>Color Mode</source>
        <translation>Tryb koloru</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <source>Output Settings</source>
        <translation>Ustawienia wyjściowe</translation>
    </message>
    <message>
        <source>Reverse</source>
        <translation>Odwrócić</translation>
    </message>
    <message>
        <source>Grayscale</source>
        <translation>Skala odcieni szarości</translation>
    </message>
    <message>
        <source>Short side</source>
        <translation>Krótka strona</translation>
    </message>
    <message>
        <source>Collate</source>
        <translation>Sortuj</translation>
    </message>
    <message>
        <source>Copies:</source>
        <translation>Kopie:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Strony od</translation>
    </message>
    <message>
        <source>Page Set:</source>
        <translation>Ustawienia strony:</translation>
    </message>
    <message>
        <source>Duplex Printing</source>
        <translation>Drukowanie dwustronne</translation>
    </message>
</context>
<context>
    <name>QPrintPreviewDialog</name>
    <message>
        <source>%1%</source>
        <translation>%1%</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation>Podgląd wydruku</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Drukuj</translation>
    </message>
    <message>
        <source>Fit page</source>
        <translation>На всю страницу</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation>Powiększ</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Poziomo</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation>Pomniejsz</translation>
    </message>
    <message>
        <source>Fit width</source>
        <translation>По ширине</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Pionowo</translation>
    </message>
    <message>
        <source>Page Setup</source>
        <translation>Ustawienia strony</translation>
    </message>
    <message>
        <source>Page setup</source>
        <translation>Ustawienia strony</translation>
    </message>
    <message>
        <source>Show overview of all pages</source>
        <translation>Pokaż przegląd wszystkich stron</translation>
    </message>
    <message>
        <source>First page</source>
        <translation>Первая страница</translation>
    </message>
    <message>
        <source>Last page</source>
        <translation>Ostatnia strona</translation>
    </message>
    <message>
        <source>Show single page</source>
        <translation>Pokaż pojedynczą stronę</translation>
    </message>
    <message>
        <source>Export to PDF</source>
        <translation>Экспорт в PDF</translation>
    </message>
    <message>
        <source>Previous page</source>
        <translation>Poprzednia strona</translation>
    </message>
    <message>
        <source>Next page</source>
        <translation>Następna Strona</translation>
    </message>
    <message>
        <source>Show facing pages</source>
        <translation>Pokaż strony sąsiadujące</translation>
    </message>
    <message>
        <source>Export to PostScript</source>
        <translation>Esporta come PostScript</translation>
    </message>
</context>
<context>
    <name>QErrorMessage</name>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>Fatal Error:</source>
        <translation>Błąd krytyczny:</translation>
    </message>
    <message>
        <source>&amp;Show this message again</source>
        <translation>&amp;Pokaż ponownie tę wiadomość</translation>
    </message>
    <message>
        <source>Debug Message:</source>
        <translation>Komunikat debugowania:</translation>
    </message>
    <message>
        <source>Warning:</source>
        <translation>Ostrzeżenie:</translation>
    </message>
</context>
<context>
    <name>QGnomeTheme</name>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Zapisz</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Zamknij</translation>
    </message>
    <message>
        <source>Close without Saving</source>
        <translation>Zamknij bez zapisywania</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
</context>
<context>
    <name>QPrintWidget</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <source>&amp;Name:</source>
        <translation>&amp;Nazwa:</translation>
    </message>
    <message>
        <source>Output &amp;file:</source>
        <translation>&amp;Plik wyjściowy:</translation>
    </message>
    <message>
        <source>P&amp;roperties</source>
        <translation>&amp;Właściwości</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Podgląd</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Drukarka</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Lokalizacja:</translation>
    </message>
</context>
<context>
    <name>QFontDatabase</name>
    <message>
        <source>Any</source>
        <translation>Dowolny</translation>
    </message>
    <message>
        <source>Lao</source>
        <translation>Lao</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>Pogrubienie</translation>
    </message>
    <message>
        <source>Demi</source>
        <translation>Demi</translation>
    </message>
    <message>
        <source>N&apos;Ko</source>
        <translation>N&apos;Ko</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation>Tajski</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation>Chudy</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Czarny</translation>
    </message>
    <message>
        <source>Extra</source>
        <translation>Extra</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Grecki</translation>
    </message>
    <message>
        <source>Khmer</source>
        <translation>Kmerski</translation>
    </message>
    <message>
        <source>Latin</source>
        <translation>Łaciński</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Light</translation>
    </message>
    <message>
        <source>Ogham</source>
        <translation>Ogham</translation>
    </message>
    <message>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <source>Runic</source>
        <translation>Runiczny</translation>
    </message>
    <message>
        <source>Tamil</source>
        <translation>Tamil</translation>
    </message>
    <message>
        <source>Cyrillic</source>
        <translation>Cyrylica</translation>
    </message>
    <message>
        <source>Kannada</source>
        <translation>Kannada</translation>
    </message>
    <message>
        <source>Normal</source>
        <comment>The Normal or Regular font weight</comment>
        <translation>Zwykły</translation>
    </message>
    <message>
        <source>Malayalam</source>
        <translation>Malayalam</translation>
    </message>
    <message>
        <source>Extra Light</source>
        <translation>Extra Light</translation>
    </message>
    <message>
        <source>Simplified Chinese</source>
        <translation>Chiński uproszczony</translation>
    </message>
    <message>
        <source>Demi Bold</source>
        <translation>Demi Bold</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabski</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation>Hebrajski</translation>
    </message>
    <message>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>Italski</translation>
    </message>
    <message>
        <source>Korean</source>
        <translation>Koreański</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Średni</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation>Normalna</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Ukośny</translation>
    </message>
    <message>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <source>Thaana</source>
        <translation>Thaana</translation>
    </message>
    <message>
        <source>Symbol</source>
        <translation>Symbole</translation>
    </message>
    <message>
        <source>Syriac</source>
        <translation>Syryjski</translation>
    </message>
    <message>
        <source>Extra Bold</source>
        <translation>Extra Bold</translation>
    </message>
    <message>
        <source>Devanagari</source>
        <translation>Devanagari</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japoński</translation>
    </message>
    <message>
        <source>Bengali</source>
        <translation>Bengalski</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation>Ormiański</translation>
    </message>
    <message>
        <source>Sinhala</source>
        <translation>Syngaleski</translation>
    </message>
    <message>
        <source>Tibetan</source>
        <translation>Tybetański</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation>Wietnamski</translation>
    </message>
    <message>
        <source>Gujarati</source>
        <translation>Gudżarati</translation>
    </message>
    <message>
        <source>Traditional Chinese</source>
        <translation>Chiński tradycyjny</translation>
    </message>
    <message>
        <source>Georgian</source>
        <translation>Gruziński</translation>
    </message>
    <message>
        <source>Gurmukhi</source>
        <translation>Gurmukhi</translation>
    </message>
</context>
<context>
    <name>QCocoaMenuItem</name>
    <message>
        <source>Cut</source>
        <translation>Wytnij</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Zakończ</translation>
    </message>
    <message>
        <source>Quit</source>
        <translation>Opuść</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Wklej</translation>
    </message>
    <message>
        <source>Setup</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <source>Config</source>
        <translation>Konfig</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation>Info o Qt</translation>
    </message>
    <message>
        <source>Setting</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Zaznacz wszystko</translation>
    </message>
    <message>
        <source>Preference</source>
        <translation>Preferencje</translation>
    </message>
</context>
<context>
    <name>QCupsJobWidget</name>
    <message>
        <source>Job</source>
        <translation>Zadanie</translation>
    </message>
    <message>
        <source>End:</source>
        <translation>Koniec:</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Żaden</translation>
    </message>
    <message>
        <source>Banner Pages</source>
        <translation>Strony banerowe</translation>
    </message>
    <message>
        <source>Night (18:00 to 05:59)</source>
        <translation>Nocny (od 18:00 do 05:59)</translation>
    </message>
    <message>
        <source>Specific Time</source>
        <translation>Określony czas</translation>
    </message>
    <message>
        <source>Billing information:</source>
        <translation>Informacje rozliczeniowe:</translation>
    </message>
    <message>
        <source>Scheduled printing:</source>
        <translation>Zaplanowane drukowanie:</translation>
    </message>
    <message>
        <source>Secret</source>
        <translation>Tajny</translation>
    </message>
    <message>
        <source>Top Secret</source>
        <translation>Ściśle tajny</translation>
    </message>
    <message>
        <source>Start:</source>
        <translation>Start:</translation>
    </message>
    <message>
        <source>Day (06:00 to 17:59)</source>
        <translation>Dzienny (od 06:00 do 17:59)</translation>
    </message>
    <message>
        <source>Second Shift (16:00 to 23:59)</source>
        <translation>Druga zmiana (od 16:00 do 23:59)</translation>
    </message>
    <message>
        <source>Job Control</source>
        <translation>Kontrola zadań</translation>
    </message>
    <message>
        <source>Weekend (Saturday to Sunday)</source>
        <translation>Weekend (od soboty do niedzieli)</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>Classified</source>
        <translation>Sklasyfikowany</translation>
    </message>
    <message>
        <source>Third Shift (00:00 to 07:59)</source>
        <translation>Trzecia zmiana (od 00:00 do 07:59)</translation>
    </message>
    <message>
        <source>Hold Indefinitely</source>
        <translation>Wstrzymaj na czas nieokreślony</translation>
    </message>
    <message>
        <source>Print Immediately</source>
        <translation>Drukuj natychmiast</translation>
    </message>
    <message>
        <source>Confidential</source>
        <translation>Poufny</translation>
    </message>
    <message>
        <source>Job priority:</source>
        <translation>Priorytet zadania:</translation>
    </message>
    <message>
        <source>Unclassified</source>
        <translation>Niesklasyfikowany</translation>
    </message>
</context>
<context>
    <name>QScrollBar</name>
    <message>
        <source>Top</source>
        <translation>Góra</translation>
    </message>
    <message>
        <source>Scroll down</source>
        <translation>Przewiń w dół</translation>
    </message>
    <message>
        <source>Scroll here</source>
        <translation>Przewiń tutaj</translation>
    </message>
    <message>
        <source>Scroll left</source>
        <translation>Przewiń w lewo</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Dolny</translation>
    </message>
    <message>
        <source>Page up</source>
        <translation>Strona w górę</translation>
    </message>
    <message>
        <source>Page right</source>
        <translation>Strona w prawo</translation>
    </message>
    <message>
        <source>Scroll up</source>
        <translation>Przewiń do góry</translation>
    </message>
    <message>
        <source>Scroll right</source>
        <translation>Przewiń w prawo</translation>
    </message>
    <message>
        <source>Left edge</source>
        <translation>Lewa krawędź</translation>
    </message>
    <message>
        <source>Page down</source>
        <translation>Strona w dół</translation>
    </message>
    <message>
        <source>Page left</source>
        <translation>Strona w lewo</translation>
    </message>
    <message>
        <source>Right edge</source>
        <translation>Prawa krawędź</translation>
    </message>
</context>
<context>
    <name>QSpiAccessibleBridge</name>
    <message>
        <source>row</source>
        <translation>wiersz</translation>
    </message>
    <message>
        <source>cell</source>
        <translation>komórka</translation>
    </message>
    <message>
        <source>dial</source>
        <translation>wybierz</translation>
    </message>
    <message>
        <source>form</source>
        <translation>formularz</translation>
    </message>
    <message>
        <source>grip</source>
        <translation>uchwyt</translation>
    </message>
    <message>
        <source>link</source>
        <translation>link</translation>
    </message>
    <message>
        <source>list</source>
        <translation>lista</translation>
    </message>
    <message>
        <source>note</source>
        <translation>uwaga</translation>
    </message>
    <message>
        <source>text</source>
        <translation>text</translation>
    </message>
    <message>
        <source>tree</source>
        <translation>drzewo</translation>
    </message>
    <message>
        <source>animation</source>
        <translation>animacja</translation>
    </message>
    <message>
        <source>chart</source>
        <translation>graficzny</translation>
    </message>
    <message>
        <source>clock</source>
        <translation>zegar</translation>
    </message>
    <message>
        <source>frame</source>
        <translation>rama</translation>
    </message>
    <message>
        <source>label</source>
        <translation>etykieta</translation>
    </message>
    <message>
        <source>panel</source>
        <translation>panel</translation>
    </message>
    <message>
        <source>space</source>
        <translation>spacja</translation>
    </message>
    <message>
        <source>sound</source>
        <translation>dźwięk</translation>
    </message>
    <message>
        <source>table</source>
        <translation>stół</translation>
    </message>
    <message>
        <source>radio button</source>
        <translation>przycisk radiowy</translation>
    </message>
    <message>
        <source>page tab list</source>
        <translation>lista kart strony</translation>
    </message>
    <message>
        <source>web document</source>
        <translation>dokument web</translation>
    </message>
    <message>
        <source>combo box</source>
        <translation>pole kombi</translation>
    </message>
    <message>
        <source>color chooser</source>
        <translation>wybór koloru</translation>
    </message>
    <message>
        <source>menu item</source>
        <translation>pozycja menu</translation>
    </message>
    <message>
        <source>document</source>
        <translation>dokument</translation>
    </message>
    <message>
        <source>scroll bar</source>
        <translation>pasek przewijania</translation>
    </message>
    <message>
        <source>tool bar</source>
        <translation>pasek narzędzi</translation>
    </message>
    <message>
        <source>tool tip</source>
        <translation>etykietka narzędzia</translation>
    </message>
    <message>
        <source>text caret</source>
        <translation>kursor tekstu</translation>
    </message>
    <message>
        <source>button menu</source>
        <translation>menu przycisku</translation>
    </message>
    <message>
        <source>separator</source>
        <translation>separator</translation>
    </message>
    <message>
        <source>canvas</source>
        <translation>płótno</translation>
    </message>
    <message>
        <source>column</source>
        <translation>kolumna</translation>
    </message>
    <message>
        <source>cursor</source>
        <translation>cursor</translation>
    </message>
    <message>
        <source>dialog</source>
        <translation>dialog</translation>
    </message>
    <message>
        <source>filler</source>
        <translation>wypełniacz</translation>
    </message>
    <message>
        <source>footer</source>
        <translation>stopka</translation>
    </message>
    <message>
        <source>push button</source>
        <translation>naciśnij przycisk</translation>
    </message>
    <message>
        <source>row header</source>
        <translation>nagłówek wiersza</translation>
    </message>
    <message>
        <source>spin box</source>
        <translation>cyfrowy obszar wyboru</translation>
    </message>
    <message>
        <source>splitter</source>
        <translation>rozdzielacz</translation>
    </message>
    <message>
        <source>slider</source>
        <translation>suwak</translation>
    </message>
    <message>
        <source>button with drop down grid</source>
        <translation>przycisk z rozwijanym menu wyświetlającym siatkę</translation>
    </message>
    <message>
        <source>page tab</source>
        <translation>zakładka strony</translation>
    </message>
    <message>
        <source>window</source>
        <translation>okno</translation>
    </message>
    <message>
        <source>invalid role</source>
        <translation>nieprawidłowa rola</translation>
    </message>
    <message>
        <source>paragraph</source>
        <translation>akapit</translation>
    </message>
    <message>
        <source>equation</source>
        <translation>równanie</translation>
    </message>
    <message>
        <source>complementary content</source>
        <translation>zawartość uzupełniająca</translation>
    </message>
    <message>
        <source>section</source>
        <translation>sekcja</translation>
    </message>
    <message>
        <source>assistant</source>
        <translation>asystent</translation>
    </message>
    <message>
        <source>list item</source>
        <translation>element listy</translation>
    </message>
    <message>
        <source>indicator</source>
        <translation>wskaźnik</translation>
    </message>
    <message>
        <source>title bar</source>
        <translation>pasek tytułu</translation>
    </message>
    <message>
        <source>tree item</source>
        <translation>element drzewa</translation>
    </message>
    <message>
        <source>check box</source>
        <translation>pole wyboru</translation>
    </message>
    <message>
        <source>status bar</source>
        <translation>pasek stanu</translation>
    </message>
    <message>
        <source>progress bar</source>
        <translation>pasek postępu</translation>
    </message>
    <message>
        <source>alert message</source>
        <translation>komunikat ostrzegawczy</translation>
    </message>
    <message>
        <source>property page</source>
        <translation>strona właściwości</translation>
    </message>
    <message>
        <source>popup menu</source>
        <translation>menu podręczne</translation>
    </message>
    <message>
        <source>layered pane</source>
        <translation>warstwowy panel</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>nieznany</translation>
    </message>
    <message>
        <source>menu bar</source>
        <translation>pasek menu</translation>
    </message>
    <message>
        <source>column header</source>
        <translation>nagłówek kolumny</translation>
    </message>
    <message>
        <source>button with drop down</source>
        <translation>przycisk z rozwijanym menu</translation>
    </message>
    <message>
        <source>hotkey field</source>
        <translation>pole skrótu</translation>
    </message>
    <message>
        <source>graphic</source>
        <translation>graficzny</translation>
    </message>
    <message>
        <source>help balloon</source>
        <translation>dymki pomocy</translation>
    </message>
    <message>
        <source>heading</source>
        <translation>nagłówek</translation>
    </message>
    <message>
        <source>application</source>
        <translation>aplikacja</translation>
    </message>
</context>
<context>
    <name>QFile</name>
    <message>
        <source>Cannot remove source file</source>
        <translation>Nie można usunąć pliku źródłowego</translation>
    </message>
    <message>
        <source>Destination file is the same file.</source>
        <translation>Plik docelowy to ten sam plik.</translation>
    </message>
    <message>
        <source>Error while renaming.</source>
        <translation>Błąd podczas zmiany nazwy.</translation>
    </message>
    <message>
        <source>Cannot create %1 for output</source>
        <translation>Nie można otworzyć %1 dla danych wyjściowych</translation>
    </message>
    <message>
        <source>Failure to write block</source>
        <translation>Brak zapisu bloku</translation>
    </message>
    <message>
        <source>Cannot open %1 for input</source>
        <translation>Nie można otworzyć %1 dla danych wejściowych</translation>
    </message>
    <message>
        <source>Destination file exists</source>
        <translation>Plik docelowy istnieje</translation>
    </message>
    <message>
        <source>Cannot open for output</source>
        <translation>Nie można otworzyć dla wyjścia</translation>
    </message>
    <message>
        <source>Will not rename sequential file using block copy</source>
        <translation>Nie zmieni nazwy pliku sekwencyjnego za pomocą kopii blokowej</translation>
    </message>
    <message>
        <source>Source file does not exist.</source>
        <translation>Plik źródłowy nie istnieje.</translation>
    </message>
    <message>
        <source>Unable to restore from %1: %2</source>
        <translation>Nie można przywrócić z %1 : %2</translation>
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <source>Back</source>
        <translation>Wstecz</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Plik</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Otwórz</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Otwórz</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Zapisz</translation>
    </message>
    <message>
        <source>Alias</source>
        <translation>Alias</translation>
    </message>
    <message>
        <source>Drive</source>
        <translation>Napęd</translation>
    </message>
    <message>
        <source>Files</source>
        <translation>Pliki</translation>
    </message>
    <message>
        <source>Show </source>
        <translation>Pokaż </translation>
    </message>
    <message>
        <source>&apos;%1&apos; is write protected.
Do you want to delete it anyway?</source>
        <translation>&quot;%1&quot;  jest chroniony przed zapisem.
Czy nadal chcesz go usunąć?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete &apos;%1&apos;?</source>
        <translation>Czy na pewno chcesz usunąć &quot;%1&quot;?</translation>
    </message>
    <message>
        <source>List of places and bookmarks</source>
        <translation>Lista miejsc i zakładek</translation>
    </message>
    <message>
        <source>File &amp;name:</source>
        <translation>&amp;Nazwa pliku:</translation>
    </message>
    <message>
        <source>Alt+Left</source>
        <translation>Alt+Left</translation>
    </message>
    <message>
        <source>Alt+Up</source>
        <translation>Alt+Up</translation>
    </message>
    <message>
        <source>File Folder</source>
        <translation>Folder plików</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>New Folder</source>
        <translation>Nowy folder</translation>
    </message>
    <message>
        <source>Folder</source>
        <translation>Folder</translation>
    </message>
    <message>
        <source>Parent Directory</source>
        <translation>Katalog nadrzędny</translation>
    </message>
    <message>
        <source>&amp;New Folder</source>
        <translation>&amp;Nowy folder</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>My Computer</source>
        <translation>Mój komputer</translation>
    </message>
    <message>
        <source>Look in:</source>
        <translation>Sprawdź w:</translation>
    </message>
    <message>
        <source>Alt+Right</source>
        <translation>Alt+Right</translation>
    </message>
    <message>
        <source>Create a New Folder</source>
        <translation>Utwórz nowy folder</translation>
    </message>
    <message>
        <source>%1 File</source>
        <translation>%1Plik</translation>
    </message>
    <message>
        <source>Files of type:</source>
        <translation>Pliki typu:</translation>
    </message>
    <message>
        <source>Find Directory</source>
        <translation>Znajdź katalog</translation>
    </message>
    <message>
        <source>Show &amp;hidden files</source>
        <translation>Pokaż &amp;ukryte pliki</translation>
    </message>
    <message>
        <source>Save As</source>
        <translation>Zapisz jako</translation>
    </message>
    <message>
        <source>%1
Directory not found.
Please verify the correct directory name was given.</source>
        <translation>%1
Nie znaleziono katalogu.
Sprawdź, czy podana została prawidłowa nazwa katalogu.</translation>
    </message>
    <message>
        <source>Sidebar</source>
        <translation>Panel boczny</translation>
    </message>
    <message>
        <source>List View</source>
        <translation>Widok listy</translation>
    </message>
    <message>
        <source>&amp;Choose</source>
        <translation>&amp;Wybierz</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Usuń</translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation>Wszystkie Pliki (*)</translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation>Wszystkie Pliki (*)</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Katalogi</translation>
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation>&amp;Zmień nazwę</translation>
    </message>
    <message>
        <source>Could not delete directory.</source>
        <translation>Nie można usunąć katalogu.</translation>
    </message>
    <message>
        <source>Directory:</source>
        <translation>Katalog:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Nieznany</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>%1 już istnieje.
Czy chcesz go zamienić?</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Do przodu</translation>
    </message>
    <message>
        <source>Go forward</source>
        <translation>Przejdź do następnego elementu</translation>
    </message>
    <message>
        <source>Go to the parent directory</source>
        <translation>Przejdź do folderu nadrzędnego</translation>
    </message>
    <message>
        <source>Recent Places</source>
        <translation>Najnowsze lokalizacje</translation>
    </message>
    <message>
        <source>Go back</source>
        <translation>Wróć</translation>
    </message>
    <message>
        <source>Change to detail view mode</source>
        <translation>Przejdź do trybu widoku szczegółów</translation>
    </message>
    <message>
        <source>Create New Folder</source>
        <translation>Stwórz nowy folder</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Skrót</translation>
    </message>
    <message>
        <source>Detail View</source>
        <translation>Widok szczegółowy</translation>
    </message>
    <message>
        <source>%1
File not found.
Please verify the correct file name was given.</source>
        <translation>%1
Nie znaleziono pliku.
Sprawdź, czy podano prawidłową nazwę pliku</translation>
    </message>
    <message>
        <source>Change to list view mode</source>
        <translation>Przejdź do trybu widoku listy</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>Cu&amp;t</source>
        <translation>Wy&amp;tnij</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiuj</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Ponów</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Cofnij</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Wklej</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Zaznacz wszystko</translation>
    </message>
</context>
<context>
    <name>QWidgetTextControl</name>
    <message>
        <source>Cu&amp;t</source>
        <translation>Wy&amp;tnij</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopiuj</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Ponów</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Cofnij</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Wklej</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Zaznacz wszystko</translation>
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation>Kopiuj &amp;adres odnośnika</translation>
    </message>
</context>
<context>
    <name>QWizard</name>
    <message>
        <source>Done</source>
        <translation>Gotowe</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Pomoc</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Następny</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Commit</source>
        <translation>Zatwierdź</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Kontynuuj</translation>
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation>&amp;Koniec</translation>
    </message>
    <message>
        <source>&amp;Next &gt;</source>
        <translation>&amp;Następny &gt;</translation>
    </message>
    <message>
        <source>Go Back</source>
        <translation>Wróć</translation>
    </message>
    <message>
        <source>&lt; &amp;Back</source>
        <translation>&lt; &amp;Powrót</translation>
    </message>
</context>
<context>
    <name>QPrintPropertiesWidget</name>
    <message>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Strona</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Zaawansowane</translation>
    </message>
</context>
<context>
    <name>QMdiSubWindow</name>
    <message>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation>&amp;Przenieś</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Rozmiar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimalizuj</translation>
    </message>
    <message>
        <source>Shade</source>
        <translation>Odcień</translation>
    </message>
    <message>
        <source>Stay on &amp;Top</source>
        <translation>Bądź na &amp;bieżąco</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Zamknij</translation>
    </message>
    <message>
        <source>- [%1]</source>
        <translation>- [%1]</translation>
    </message>
    <message>
        <source>%1 - [%2]</source>
        <translation>%1 - [%2]</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Przywróć</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Przywróć</translation>
    </message>
    <message>
        <source>Maximize</source>
        <translation>Maksymalizuj</translation>
    </message>
    <message>
        <source>Unshade</source>
        <translation>Usuń cieniowanie</translation>
    </message>
    <message>
        <source>Mi&amp;nimize</source>
        <translation>Mi&amp;nimalizuj</translation>
    </message>
    <message>
        <source>Ma&amp;ximize</source>
        <translation>Ma&amp;ksymalizuj</translation>
    </message>
    <message>
        <source>Restore Down</source>
        <translation>Przywróć w dół</translation>
    </message>
</context>
<context>
    <name>QStandardPaths</name>
    <message>
        <source>Home</source>
        <translation>Baza</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation>Pamięć podręczna</translation>
    </message>
    <message>
        <source>Fonts</source>
        <translation>Czcionki</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Muzyka</translation>
    </message>
    <message>
        <source>Shared Cache</source>
        <translation>Udostępniona pamięć podręczna</translation>
    </message>
    <message>
        <source>Shared Configuration</source>
        <translation>Konfiguracja udostępniona</translation>
    </message>
    <message>
        <source>Movies</source>
        <translation>Filmy</translation>
    </message>
    <message>
        <source>Application Configuration</source>
        <translation>Konfiguracja aplikacji</translation>
    </message>
    <message>
        <source>Download</source>
        <translation>Pobierz</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation>Konfiguracja</translation>
    </message>
    <message>
        <source>Application Data</source>
        <translation>Dane aplikacji</translation>
    </message>
    <message>
        <source>Runtime</source>
        <translation>Czas wykonywania</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Dokumenty</translation>
    </message>
    <message>
        <source>Desktop</source>
        <translation>Pulpit</translation>
    </message>
    <message>
        <source>Temporary Directory</source>
        <translation>Katalog tymczasowy</translation>
    </message>
    <message>
        <source>Shared Data</source>
        <translation>Udostępnione dane</translation>
    </message>
    <message>
        <source>Applications</source>
        <translation>Aplikacje</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Zdjęcia</translation>
    </message>
</context>
<context>
    <name>QDirModel</name>
    <message>
        <source>Kind</source>
        <translation>Rodzaj</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Date Modified</source>
        <translation>Data modyfikacji</translation>
    </message>
</context>
<context>
    <name>QFileSystemModel</name>
    <message>
        <source>Kind</source>
        <translation>Rodzaj</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 TB</source>
        <translation>%1 TB</translation>
    </message>
    <message>
        <source>&lt;b&gt;The name &quot;%1&quot; can not be used.&lt;/b&gt;&lt;p&gt;Try using another name, with fewer characters or no punctuations marks.</source>
        <translation>&lt;b&gt;Nie można użyć nazwy „% 1”.&lt;/b&gt;&lt;p&gt;Spróbuj użyć innej nazwy z mniejszą liczbą znaków lub bez znaków interpunkcyjnych.</translation>
    </message>
    <message>
        <source>%1 bytes</source>
        <translation>%1 bajtów</translation>
    </message>
    <message>
        <source>My Computer</source>
        <translation>Mój komputer</translation>
    </message>
    <message>
        <source>Computer</source>
        <translation>Komputer</translation>
    </message>
    <message>
        <source>Invalid filename</source>
        <translation>Nieprawidłowa nazwa pliku</translation>
    </message>
    <message>
        <source>%1 byte(s)</source>
        <translation>%1 bajt(y)</translation>
    </message>
    <message>
        <source>Date Modified</source>
        <translation>Data modyfikacji</translation>
    </message>
</context>
<context>
    <name>QPPDOptionsModel</name>
    <message>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Wartość</translation>
    </message>
</context>
<context>
    <name>QUndoGroup</name>
    <message>
        <source>Redo</source>
        <translation>Ponów</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Cofnij</translation>
    </message>
    <message>
        <source>Undo</source>
        <comment>Default text for undo action</comment>
        <translation>Cofnij</translation>
    </message>
    <message>
        <source>Redo %1</source>
        <translation>Ponów %1</translation>
    </message>
    <message>
        <source>Undo %1</source>
        <translation>Cofnij %1</translation>
    </message>
    <message>
        <source>Redo</source>
        <comment>Default text for redo action</comment>
        <translation>Ponów</translation>
    </message>
</context>
<context>
    <name>QUndoStack</name>
    <message>
        <source>Redo</source>
        <translation>Ponów</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Cofnij</translation>
    </message>
    <message>
        <source>Undo</source>
        <comment>Default text for undo action</comment>
        <translation>Cofnij</translation>
    </message>
    <message>
        <source>Redo %1</source>
        <translation>Ponów %1</translation>
    </message>
    <message>
        <source>Undo %1</source>
        <translation>Cofnij %1</translation>
    </message>
    <message>
        <source>Redo</source>
        <comment>Default text for redo action</comment>
        <translation>Ponów</translation>
    </message>
</context>
<context>
    <name>QComboBox</name>
    <message>
        <source>True</source>
        <translation>Prawda</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Fałsz</translation>
    </message>
    <message>
        <source>Open the combo box selection popup</source>
        <translation>Otwórz listę rozwijaną</translation>
    </message>
</context>
<context>
    <name>QSslSocket</name>
    <message>
        <source>Error creating SSL session: %1</source>
        <translation>Błąd podczas tworzenia sesji SSL, %1</translation>
    </message>
    <message>
        <source>Error creating SSL session, %1</source>
        <translation>Błąd podczas tworzenia sesji SSL, %1</translation>
    </message>
    <message>
        <source>Error when setting the elliptic curves (%1)</source>
        <translation>Błąd podczas ustawiania krzywych eliptycznych (%1)</translation>
    </message>
    <message>
        <source>The certificate&apos;s notAfter field contains an invalid time</source>
        <translation>Pole notAfter certyfikatu zawiera niepoprawny czas</translation>
    </message>
    <message>
        <source>No error</source>
        <translation>Brak błędu</translation>
    </message>
    <message>
        <source>Cannot provide a certificate with no key, %1</source>
        <translation>Nie można dostarczyć certyfikatu bez klucza, %1</translation>
    </message>
    <message>
        <source>Unable to write data: %1</source>
        <translation>Nie można zapisać danych: %1</translation>
    </message>
    <message>
        <source>The basicConstraints path length parameter has been exceeded</source>
        <translation>Parametr długości ścieżki basicConstraints został przekroczony</translation>
    </message>
    <message>
        <source>The certificate has expired</source>
        <translation>Certyfikat wygasł</translation>
    </message>
    <message>
        <source>The TLS/SSL connection has been closed</source>
        <translation>Połączenie TLS/SSL zostało zamknięte</translation>
    </message>
    <message>
        <source>Error during SSL handshake: %1</source>
        <translation>Błąd podczas uzgadniania SSL: %1</translation>
    </message>
    <message>
        <source>Error loading local certificate, %1</source>
        <translation>Błąd podczas ładowania certyfikatu lokalnego, %1</translation>
    </message>
    <message>
        <source>The certificate is self-signed, and untrusted</source>
        <translation>Certyfikat jest samopodpisany i niezaufany</translation>
    </message>
    <message>
        <source>Unable to init SSL Context: %1</source>
        <translation>Nie można zainicjować kontekstu SSL: %1</translation>
    </message>
    <message>
        <source>Unable to init Ssl Context: %1</source>
        <translation>Nie można zainicjować kontekstu SSL: %1</translation>
    </message>
    <message>
        <source>The peer did not present any certificate</source>
        <translation>Uczestnik nie przedstawił żadnego certyfikatu</translation>
    </message>
    <message>
        <source>unsupported protocol</source>
        <translation>nieobsługiwany protokół</translation>
    </message>
    <message>
        <source>The root CA certificate is marked to reject the specified purpose</source>
        <translation>Certyfikat głównego urzędu certyfikacji jest oznaczony, aby odrzucić określony cel</translation>
    </message>
    <message>
        <source>Invalid or empty cipher list (%1)</source>
        <translation>Nieprawidłowa lub pusta lista szyfrowania (%1)</translation>
    </message>
    <message>
        <source>No certificates could be verified</source>
        <translation>Nie można zweryfikować certyfikatów</translation>
    </message>
    <message>
        <source>The current candidate issuer certificate was rejected because its issuer name and serial number was present and did not match the authority key identifier of the current certificate</source>
        <translation>Obecny certyfikat wystawcy kandydata został odrzucony, ponieważ jego nazwa i numer seryjny były obecne i nie zgadzają się z identyfikatorem klucza urzędowego bieżącego certyfikatu</translation>
    </message>
    <message>
        <source>The root CA certificate is not trusted for this purpose</source>
        <translation>Certyfikat głównego urzędu certyfikacji nie jest zaufany w tym celu</translation>
    </message>
    <message>
        <source>The host name did not match any of the valid hosts for this certificate</source>
        <translation>Nazwa hosta nie pasuje do żadnego z prawidłowych hostów tego certyfikatu</translation>
    </message>
    <message>
        <source>The root certificate of the certificate chain is self-signed, and untrusted</source>
        <translation>Główny certyfikat łańcucha certyfikatów jest samopodpisany i niezaufany</translation>
    </message>
    <message>
        <source>The peer certificate is blacklisted</source>
        <translation>Certyfikat równorzędny znajduje się na czarnej liście</translation>
    </message>
    <message>
        <source>The certificate signature could not be decrypted</source>
        <translation>Nie można odszyfrować podpisu certyfikatu</translation>
    </message>
    <message>
        <source>The supplied certificate is unsuitable for this purpose</source>
        <translation>Dostarczony certyfikat jest nieodpowiedni do tego celu</translation>
    </message>
    <message>
        <source>Private key does not certify public key, %1</source>
        <translation>Klucz prywatny nie certyfikuje klucza publicznego, %1</translation>
    </message>
    <message>
        <source>Error creating SSL context (%1)</source>
        <translation>Błąd podczas tworzenia kontekstu SSL (%1)</translation>
    </message>
    <message>
        <source>OpenSSL version too old, need at least v1.0.2</source>
        <translation>Wersja OpenSSL jest za stara, potrzebujesz co najmniej wersji 1.0.2</translation>
    </message>
    <message>
        <source>The issuer certificate could not be found</source>
        <translation>Nie można znaleźć certyfikatu wystawcy</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
    <message>
        <source>The current candidate issuer certificate was rejected because its subject name did not match the issuer name of the current certificate</source>
        <translation>Obecny certyfikat wystawcy kandydata został odrzucony, ponieważ jego nazwa podmiotu nie zgadza się z nazwą wystawcy bieżącego certyfikatu</translation>
    </message>
    <message>
        <source>Error while reading: %1</source>
        <translation>Błąd podczas czytania: %1</translation>
    </message>
    <message>
        <source>The certificate&apos;s notBefore field contains an invalid time</source>
        <translation>Pole notBefore certyfikatu zawiera niepoprawny czas</translation>
    </message>
    <message>
        <source>Error loading private key, %1</source>
        <translation>Błąd podczas ładowania klucza prywatnego, %1</translation>
    </message>
    <message>
        <source>The certificate is not yet valid</source>
        <translation>Certyfikat nie jest jeszcze ważny</translation>
    </message>
    <message>
        <source>The public key in the certificate could not be read</source>
        <translation>Nie można odczytać klucza publicznego w certyfikacie</translation>
    </message>
    <message>
        <source>One of the CA certificates is invalid</source>
        <translation>Jeden z certyfikatów urzędu certyfikacji jest nieprawidłowy</translation>
    </message>
    <message>
        <source>The signature of the certificate is invalid</source>
        <translation>Podpis certyfikatu jest nieprawidłowy</translation>
    </message>
    <message>
        <source>The issuer certificate of a locally looked up certificate could not be found</source>
        <translation>Nie można odnaleźć certyfikatu wystawcy certyfikatu wyszukiwania lokalnego</translation>
    </message>
    <message>
        <source>Unable to decrypt data: %1</source>
        <translation>Nie można odszyfrować danych: %1</translation>
    </message>
</context>
<context>
    <name>QLocalSocket</name>
    <message>
        <source>%1: Connection error</source>
        <translation>%1: Błąd połączenia</translation>
    </message>
    <message>
        <source>%1: Access denied</source>
        <translation>%1: Odmowa dostępu</translation>
    </message>
    <message>
        <source>%1: Operation not permitted when socket is in this state</source>
        <translation>%1: Działanie niedozwolone, gdy gniazdo jest w tym stanie</translation>
    </message>
    <message>
        <source>%1: Connection refused</source>
        <translation>%1: Połączenie odrzucone</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: Nieznany błąd %2</translation>
    </message>
    <message>
        <source>%1: Socket access error</source>
        <translation>%1: Błąd dostępu do gniazda</translation>
    </message>
    <message>
        <source>%1: Socket resource error</source>
        <translation>%1: Błąd zasobu gniazda</translation>
    </message>
    <message>
        <source>Trying to connect while connection is in progress</source>
        <translation>Próba nawiązania połączenia w trakcie połączenia</translation>
    </message>
    <message>
        <source>%1: The socket operation is not supported</source>
        <translation>%1: Operacja gniazda nie jest obsługiwana</translation>
    </message>
    <message>
        <source>%1: Invalid name</source>
        <translation>%1: Nieprawidłowa nazwa</translation>
    </message>
    <message>
        <source>%1: Unknown error</source>
        <translation>%1: Nieznany błąd</translation>
    </message>
    <message>
        <source>%1: Socket operation timed out</source>
        <translation>%1: Upłynął limit czasu operacji gniazda</translation>
    </message>
    <message>
        <source>%1: Datagram too large</source>
        <translation>%1: Datagram za duży</translation>
    </message>
    <message>
        <source>%1: Remote closed</source>
        <translation>%1: Zamknięto zdalnie</translation>
    </message>
</context>
<context>
    <name>QRegularExpression</name>
    <message>
        <source>digit expected after (?+</source>
        <translation>cyfra oczekiwana po (?+</translation>
    </message>
    <message>
        <source>unmatched parentheses</source>
        <translation>niedopasowane nawiasy</translation>
    </message>
    <message>
        <source>inconsistent NEWLINE options</source>
        <translation>Opcje NEWLINE nie są kompatybilne</translation>
    </message>
    <message>
        <source>(?R or (?[+-]digits must be followed by )</source>
        <translation>cyfry w (?R lub (?[+-]muszą być poprzedzone )</translation>
    </message>
    <message>
        <source>syntax error in subpattern name (missing terminator)</source>
        <translation>błąd składni w nazwie subpattern (brak terminatora)</translation>
    </message>
    <message>
        <source>missing terminating ] for character class</source>
        <translation>brak zakończenia ] dla klasy znaku</translation>
    </message>
    <message>
        <source>setting UTF is disabled by the application</source>
        <translation>ustawienie UTF jest wyłączone przez aplikację</translation>
    </message>
    <message>
        <source>\k is not followed by a braced, angle-bracketed, or quoted name</source>
        <translation>\k nie występuje po nim nazwa w nawiasie klamrowym, kątowym lub cudzysłowie</translation>
    </message>
    <message>
        <source>internal error: unexpected repeat</source>
        <translation>błąd wewnętrzny: nieoczekiwane powtórzenie</translation>
    </message>
    <message>
        <source>this version of PCRE is not compiled with PCRE_UCP support</source>
        <translation>ta wersja PCRE nie jest skompilowana z obsługą PCRE_UCP</translation>
    </message>
    <message>
        <source>no error</source>
        <translation>brak błędu</translation>
    </message>
    <message>
        <source>POSIX named classes are supported only within a class</source>
        <translation>Nazwane klasy POSIX są obsługiwane tylko w obrębie klasy</translation>
    </message>
    <message>
        <source>invalid UTF-16 string</source>
        <translation>niepoprawny ciąg UTF-16</translation>
    </message>
    <message>
        <source>invalid UTF-32 string</source>
        <translation>niepoprawny ciąg UTF-32</translation>
    </message>
    <message>
        <source>parentheses are too deeply nested (stack check)</source>
        <translation>nawiasy są zbyt głęboko zagnieżdżone (kontrola stosu)</translation>
    </message>
    <message>
        <source>\g is not followed by a braced, angle-bracketed, or quoted name/number or by a plain number</source>
        <translation>\g po którym nie następuje nazwa/liczba w nawiasach klamrowych, kątowych lub cudzysłowach ani zwykła liczba</translation>
    </message>
    <message>
        <source>invalid escape sequence in character class</source>
        <translation>niepoprawna sekwencja zmiany znaczenia w klasie znaków</translation>
    </message>
    <message>
        <source>missing opening brace after \o</source>
        <translation>brak nawiasu otwierającego po \o</translation>
    </message>
    <message>
        <source>range out of order in character class</source>
        <translation>zakres spoza porządku w klasie znaku</translation>
    </message>
    <message>
        <source>(*MARK) must have an argument</source>
        <translation>(*MARK) musi mieć argument</translation>
    </message>
    <message>
        <source>this version of PCRE is not compiled with PCRE_UTF8 support</source>
        <translation>ta wersja PCRE nie jest skompilowana z obsługą PCRE_UTF8</translation>
    </message>
    <message>
        <source>too many forward references</source>
        <translation>zbyt wiele referencji</translation>
    </message>
    <message>
        <source>a numbered reference must not be zero</source>
        <translation>numerowane odniesienie nie może wynosić zero</translation>
    </message>
    <message>
        <source>reference to non-existent subpattern</source>
        <translation>odniesienie do nieistniejącego wzorca</translation>
    </message>
    <message>
        <source>PCRE does not support \L, \l, \N{name}, \U, or \u</source>
        <translation>PCRE nie obsługuje \L, \l, \N{name}, \U lub \u</translation>
    </message>
    <message>
        <source>number after (?C is &gt; 255</source>
        <translation>liczba po (?C jest&gt; 255</translation>
    </message>
    <message>
        <source>two named subpatterns have the same name</source>
        <translation>dwa nazwane podwzory mają taką samą nazwę</translation>
    </message>
    <message>
        <source>internal error: overran compiling workspace</source>
        <translation>błąd wewnętrzny: przepełnienie obszaru roboczego kompilacji</translation>
    </message>
    <message>
        <source>] is an invalid data character in JavaScript compatibility mode</source>
        <translation>] jest niepoprawnym znakiem danych w trybie zgodności z JavaScript</translation>
    </message>
    <message>
        <source>unrecognized character follows \</source>
        <translation>nie został rozpoznany znak następujący po \</translation>
    </message>
    <message>
        <source>octal value is greater than \377 (not in UTF-8 mode)</source>
        <translation>wartość ósemkowa jest większa niż \377 (nie w trybie UTF-8)</translation>
    </message>
    <message>
        <source>unknown option bit(s) set</source>
        <translation>zestaw nieznanych bitów opcji</translation>
    </message>
    <message>
        <source>\N is not supported in a class</source>
        <translation>\N nie jest obsługiwane w klasie</translation>
    </message>
    <message>
        <source>non-hex character in \x{} (closing brace missing?)</source>
        <translation>znak inny niż ósemkowy w \x{} (brak nawiasu zamykającego?)</translation>
    </message>
    <message>
        <source>support for \P, \p, and \X has not been compiled</source>
        <translation>obsługa \P, \p i \X nie została skompilowana</translation>
    </message>
    <message>
        <source>character value in \x{...} sequence is too large</source>
        <translation>wartość znaku w sekwencji \x{...} jest za duża</translation>
    </message>
    <message>
        <source>invalid condition (?(0)</source>
        <translation>niepoprawny warunek (?(0)</translation>
    </message>
    <message>
        <source>regular expression is too large</source>
        <translation>wyrażenie regularne jest za duże</translation>
    </message>
    <message>
        <source>failed to get memory</source>
        <translation>nie można uzyskać pamięci</translation>
    </message>
    <message>
        <source>unknown property name after \P or \p</source>
        <translation>nieznana nazwa właściwości po \P lub \p</translation>
    </message>
    <message>
        <source>internal error: code overflow</source>
        <translation>błąd wewnętrzny: przepełnienie kodu</translation>
    </message>
    <message>
        <source>\C not allowed in lookbehind assertion</source>
        <translation>\C nie jest dozwolone w asercji</translation>
    </message>
    <message>
        <source>group name must start with a non-digit</source>
        <translation>nazwa grupy nie może zaczynać się od cyfry</translation>
    </message>
    <message>
        <source>recursive call could loop indefinitely</source>
        <translation>połączenie rekurencyjne może zapętlać się w nieskończoność</translation>
    </message>
    <message>
        <source>number is too big</source>
        <translation>liczba jest za duża</translation>
    </message>
    <message>
        <source>\c at end of pattern</source>
        <translation>\c na końcu wzoru</translation>
    </message>
    <message>
        <source>nothing to repeat</source>
        <translation>nie ma nic do powtórzenia</translation>
    </message>
    <message>
        <source>invalid UTF-8 string</source>
        <translation>niepoprawny ciąg UTF-8</translation>
    </message>
    <message>
        <source>subpattern name expected</source>
        <translation>oczekiwana nazwa subpattern</translation>
    </message>
    <message>
        <source>character value in \u.... sequence is too large</source>
        <translation>wartość znaku w sekwencji \u.... jest za duża</translation>
    </message>
    <message>
        <source>invalid range in character class</source>
        <translation>nieprawidłowy zakres w klasie znaków</translation>
    </message>
    <message>
        <source>internal error: previously-checked referenced subpattern not found</source>
        <translation>błąd wewnętrzny: poprzednio sprawdzony odnośnik nie został znaleziony</translation>
    </message>
    <message>
        <source>name is too long in (*MARK), (*PRUNE), (*SKIP), or (*THEN)</source>
        <translation>nazwa jest zbyt długa w (*MARK), (*PRUNE), (*SKIP) lub (*THEN)</translation>
    </message>
    <message>
        <source>an argument is not allowed for (*ACCEPT), (*FAIL), or (*COMMIT)</source>
        <translation>argument nie jest dozwolony dla (* ACCEPT), (* FAIL) lub (* COMMIT)</translation>
    </message>
    <message>
        <source>(*VERB) not recognized</source>
        <translation>(*VERB) nie został rozpoznany</translation>
    </message>
    <message>
        <source>assertion expected after (?(</source>
        <translation>potwierdzenia oczekiwanego po (?(</translation>
    </message>
    <message>
        <source>missing )</source>
        <translation>brakujący )</translation>
    </message>
    <message>
        <source>malformed number or name after (?(</source>
        <translation>źle sformułowany numer lub nazwa po (?(</translation>
    </message>
    <message>
        <source>number too big in {} quantifier</source>
        <translation>liczba za duża w kwantyfikatorze {}</translation>
    </message>
    <message>
        <source>unrecognized character after (?&lt;</source>
        <translation>nierozpoznany znak po (?&lt;</translation>
    </message>
    <message>
        <source>unrecognized character after (?P</source>
        <translation>nierozpoznany znak po (?P</translation>
    </message>
    <message>
        <source>parentheses are too deeply nested</source>
        <translation>nawiasy są zbyt głęboko zagnieżdżone</translation>
    </message>
    <message>
        <source>erroffset passed as NULL</source>
        <translation>parametr erroffset zostaje zmieniony na NULL</translation>
    </message>
    <message>
        <source>subpattern name is too long (maximum 32 characters)</source>
        <translation>nazwa wzorca jest za długa (maksymalnie 32 znaki)</translation>
    </message>
    <message>
        <source>non-octal character in \o{} (closing brace missing?)</source>
        <translation>znak inny niż ósemkowy w \o{0} (brak nawiasu zamykającego?)</translation>
    </message>
    <message>
        <source>closing ) for (?C expected</source>
        <translation>zamknięcie ) dla (?C oczekiwano</translation>
    </message>
    <message>
        <source>disallowed Unicode code point (&gt;= 0xd800 &amp;&amp; &lt;= 0xdfff)</source>
        <translation>niedozwolony punkt kodu Unicode (&gt;= 0xd800 &amp;&amp; &lt;= 0xdfff)</translation>
    </message>
    <message>
        <source>malformed \P or \p sequence</source>
        <translation>źle sformułowana sekwencja \ P lub \ p</translation>
    </message>
    <message>
        <source>\ at end of pattern</source>
        <translation>\ na końcu wzoru</translation>
    </message>
    <message>
        <source>POSIX collating elements are not supported</source>
        <translation>Elementy zestawiające POSIX nie są obsługiwane</translation>
    </message>
    <message>
        <source>repeating a DEFINE group is not allowed</source>
        <translation>powtarzanie grupy DEFINE jest niedozwolone</translation>
    </message>
    <message>
        <source>unrecognized character after (? or (?-</source>
        <translation>nierozpoznany znak po (? lub (?-</translation>
    </message>
    <message>
        <source>numbers out of order in {} quantifier</source>
        <translation>liczby nieuporządkowane w kwantyfikatorze {}</translation>
    </message>
    <message>
        <source>DEFINE group contains more than one branch</source>
        <translation>Grupa DEFINE zawiera więcej niż jedną gałąź</translation>
    </message>
    <message>
        <source>\c must be followed by an ASCII character</source>
        <translation>\c musi poprzedzać znak ASCII</translation>
    </message>
    <message>
        <source>unknown POSIX class name</source>
        <translation>nieznana nazwa klasy POSIX</translation>
    </message>
    <message>
        <source>conditional group contains more than two branches</source>
        <translation>grupa warunkowa zawiera więcej niż dwie gałęzie</translation>
    </message>
    <message>
        <source>lookbehind assertion is not fixed length</source>
        <translation>asercja nie ma ustalonej długości</translation>
    </message>
    <message>
        <source>missing ) after comment</source>
        <translation>brakujące) po komentarzu</translation>
    </message>
    <message>
        <source>too many named subpatterns (maximum 10000)</source>
        <translation>zbyt wiele nazwanych podwzorców (maksymalnie 10000)</translation>
    </message>
    <message>
        <source>digits missing in \x{} or \o{}</source>
        <translation>brak cyfr w \ x {} lub \ o {0}</translation>
    </message>
    <message>
        <source>internal error: unknown opcode in find_fixedlength()</source>
        <translation>błąd wewnętrzny: nieznany kod operacji w find_fixedlength()</translation>
    </message>
    <message>
        <source>different names for subpatterns of the same number are not allowed</source>
        <translation>różne nazwy subpatternów o tym samym numerze są niedozwolone</translation>
    </message>
</context>
<context>
    <name>QOCIResult</name>
    <message>
        <source>Unable to get statement type</source>
        <translation>Nie można uzyskać typu instrukcji</translation>
    </message>
    <message>
        <source>Unable to alloc statement</source>
        <translation>Nie można przydzielić instrukcji</translation>
    </message>
    <message>
        <source>Unable to goto next</source>
        <translation>Nie można przejść do następnego</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Nie można wykonać instrukcji</translation>
    </message>
    <message>
        <source>Unable to bind column for batch execute</source>
        <translation>Nie można powiązać kolumny do wykonania wsadowego</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Nie można przygotować instrukcji</translation>
    </message>
    <message>
        <source>Unable to execute batch statement</source>
        <translation>Nie można wykonać instrukcji wsadowej</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>Nie można powiązać wartości</translation>
    </message>
</context>
<context>
    <name>QFontDialog</name>
    <message>
        <source>&amp;Font</source>
        <translation>&amp;Czcionka</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Rozmiar</translation>
    </message>
    <message>
        <source>Sample</source>
        <translation>Przykład</translation>
    </message>
    <message>
        <source>Font st&amp;yle</source>
        <translation>St&amp;yl czcionki</translation>
    </message>
    <message>
        <source>Wr&amp;iting System</source>
        <translation>System p&amp;isania</translation>
    </message>
    <message>
        <source>Select Font</source>
        <translation>Wybierz czcionkę</translation>
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation>&amp;Podkreślenie</translation>
    </message>
    <message>
        <source>Effects</source>
        <translation>Efekty</translation>
    </message>
    <message>
        <source>Stri&amp;keout</source>
        <translation>Prze&amp;kreślenie</translation>
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <source>&amp;Red:</source>
        <translation>&amp;Czerwony:</translation>
    </message>
    <message>
        <source>&amp;Sat:</source>
        <translation>&amp;Nas:</translation>
    </message>
    <message>
        <source>&amp;Val:</source>
        <translation>&amp;Wal:</translation>
    </message>
    <message>
        <source>Hu&amp;e:</source>
        <translation>&amp;Odcień:</translation>
    </message>
    <message>
        <source>&amp;HTML:</source>
        <translation>&amp;HTML:</translation>
    </message>
    <message>
        <source>Select Color</source>
        <translation>Выбор цвета</translation>
    </message>
    <message>
        <source>&amp;Add to Custom Colors</source>
        <translation>&amp;Dodaj do kolorów niestandardowych</translation>
    </message>
    <message>
        <source>Bl&amp;ue:</source>
        <translation>&amp;Niebieski:</translation>
    </message>
    <message>
        <source>Pick Screen Color</source>
        <translation>Wybierz kolor ekranu</translation>
    </message>
    <message>
        <source>&amp;Pick Screen Color</source>
        <translation>&amp;Wybierz kolor ekranu</translation>
    </message>
    <message>
        <source>Cursor at %1, %2
Press ESC to cancel</source>
        <translation>Kursor w %1, %2
Naciśnij klawisz ESC, aby anulować</translation>
    </message>
    <message>
        <source>&amp;Green:</source>
        <translation>&amp;Zielony:</translation>
    </message>
    <message>
        <source>&amp;Basic colors</source>
        <translation>&amp;Podstawowe kolory</translation>
    </message>
    <message>
        <source>&amp;Custom colors</source>
        <translation>&amp;Niestandardowe kolory</translation>
    </message>
    <message>
        <source>A&amp;lpha channel:</source>
        <translation>Kanał a&amp;lfa:</translation>
    </message>
    <message>
        <source>Cursor at %1, %2, color: %3
Press ESC to cancel</source>
        <translation>Kursor na %1, %2, kolor: %3
Naciśnij klawisz ESC, aby anulować</translation>
    </message>
</context>
<context>
    <name>QSharedMemory</name>
    <message>
        <source>%1: system-imposed size restrictions</source>
        <translation>%1:system nakłada ograniczenia wielkości</translation>
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation>%1: klucz jest pusty</translation>
    </message>
    <message>
        <source>%1: key error</source>
        <translation>%1: błąd klucza</translation>
    </message>
    <message>
        <source>%1: bad name</source>
        <translation>%1: zła nazwa</translation>
    </message>
    <message>
        <source>%1: create size is less then 0</source>
        <translation>%1: utwórz rozmiar jest mniejszy niż 0</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: już istnieje</translation>
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation>%1: nieznany błąd %2</translation>
    </message>
    <message>
        <source>%1: invalid size</source>
        <translation>%1: nieprawidłowy rozmiar</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation>%1: nie można utworzyć klucza</translation>
    </message>
    <message>
        <source>%1: unable to set key on lock</source>
        <translation>%1: nie można przypisać klucza do blokady</translation>
    </message>
    <message>
        <source>%1: unable to unlock</source>
        <translation>%1: nie można odblokować</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: odmowa dostępu</translation>
    </message>
    <message>
        <source>%1: ftok failed</source>
        <translation>%1: błąd funkcji ftok</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: brak zasobów</translation>
    </message>
    <message>
        <source>%1: not attached</source>
        <translation>%1: nie dołączone</translation>
    </message>
    <message>
        <source>%1: UNIX key file doesn&apos;t exist</source>
        <translation>%1: plik klucza UNIX nie istnieje</translation>
    </message>
    <message>
        <source>%1: doesn&apos;t exist</source>
        <translation>%1: nie istnieje</translation>
    </message>
    <message>
        <source>%1: size query failed</source>
        <translation>%1: zapytanie o rozmiar nie powiodło się</translation>
    </message>
    <message>
        <source>%1: unable to lock</source>
        <translation>%1: nie można zablokować</translation>
    </message>
</context>
<context>
    <name>QXmlStream</name>
    <message>
        <source>Reference to unparsed entity &apos;%1&apos;.</source>
        <translation>Odniesienie do jednostki &apos;%1&apos;. nie jest analizowane.</translation>
    </message>
    <message>
        <source>Unexpected character &apos;%1&apos; in public id literal.</source>
        <translation>Nieoczekiwany znak &apos;%1&apos; w literalnym identyfikatorze publicznym.</translation>
    </message>
    <message>
        <source>Illegal namespace declaration.</source>
        <translation>Deklaracja przestrzeni nazw jest niepoprawna.</translation>
    </message>
    <message>
        <source>Invalid XML character.</source>
        <translation>Niepoprawny znak XML.</translation>
    </message>
    <message>
        <source>Expected character data.</source>
        <translation>Dane tekstowe są oczekiwane.</translation>
    </message>
    <message>
        <source>Standalone accepts only yes or no.</source>
        <translation>Jedynymi możliwymi wartościami dla „Standalone” są „tak” lub „nie”.</translation>
    </message>
    <message>
        <source>Invalid XML version string.</source>
        <translation>Niepoprawny ciąg wersji XML.</translation>
    </message>
    <message>
        <source>Invalid processing instruction name.</source>
        <translation>Nazwa instrukcji jest nieprawidłowa.</translation>
    </message>
    <message>
        <source>Namespace prefix &apos;%1&apos; not declared</source>
        <translation>Prefiks przestrzeni nazw &apos;%1&apos; nie został zadeklarowany</translation>
    </message>
    <message>
        <source>Entity &apos;%1&apos; not declared.</source>
        <translation>Podmiot &apos;%1&apos; nie został zadeklarowany.</translation>
    </message>
    <message>
        <source>%1 is an invalid processing instruction name.</source>
        <translation>%1 jest niepoprawną nazwą instrukcji przetwarzania.</translation>
    </message>
    <message>
        <source>The standalone pseudo attribute must appear after the encoding.</source>
        <translation>Pseudo-atrybut „samodzielny” musi pojawić się po kodowaniu.</translation>
    </message>
    <message>
        <source>Sequence &apos;]]&gt;&apos; not allowed in content.</source>
        <translation>Sekwencja &apos;]]&gt;&apos; niedozwolona w treści.</translation>
    </message>
    <message>
        <source>%1 is an invalid encoding name.</source>
        <translation>%1 to niepoprawna nazwa kodowania.</translation>
    </message>
    <message>
        <source>, but got &apos;</source>
        <translation>, odebrane &apos;</translation>
    </message>
    <message>
        <source>Start tag expected.</source>
        <translation>Oczekiwany jest tag początkowy.</translation>
    </message>
    <message>
        <source>Invalid character reference.</source>
        <translation>Odniesienie do nieprawidłowego znaku.</translation>
    </message>
    <message>
        <source>Reference to external entity &apos;%1&apos; in attribute value.</source>
        <translation>Odwołanie do jednostki zewnętrznej &apos;%1&apos; jako wartość atrybutu.</translation>
    </message>
    <message>
        <source>Expected </source>
        <translation>Oczekiwany </translation>
    </message>
    <message>
        <source>Invalid document.</source>
        <translation>Nieprawidłowy dokument.</translation>
    </message>
    <message>
        <source>Opening and ending tag mismatch.</source>
        <translation>Tagi otwierające i zamykające nie pasują do siebie.</translation>
    </message>
    <message>
        <source>Encountered incorrectly encoded content.</source>
        <translation>Napotkano treść z niepoprawnym kodowaniem.</translation>
    </message>
    <message>
        <source>Invalid attribute in XML declaration.</source>
        <translation>Atrybut w deklaracji XML jest nieprawidłowy.</translation>
    </message>
    <message>
        <source>Attribute redefined.</source>
        <translation>Atrybut został ponownie zdefiniowany.</translation>
    </message>
    <message>
        <source>%1 is an invalid PUBLIC identifier.</source>
        <translation>%1 jest niepoprawnym identyfikatorem PUBLICZNYM.</translation>
    </message>
    <message>
        <source>Extra content at end of document.</source>
        <translation>Dodatkowa treść na końcu dokumentu.</translation>
    </message>
    <message>
        <source>Attribute &apos;%1&apos; redefined.</source>
        <translation>Atrybut &apos;%1&apos; został ponownie zdefiniowany.</translation>
    </message>
    <message>
        <source>Invalid XML name.</source>
        <translation>Niepoprawna nazwa XML.</translation>
    </message>
    <message>
        <source>Premature end of document.</source>
        <translation>Przedwczesny koniec dokumentu.</translation>
    </message>
    <message>
        <source>XML declaration not at start of document.</source>
        <translation>Deklaracja XML musi znajdować się na początku dokumentu.</translation>
    </message>
    <message>
        <source>Recursive entity detected.</source>
        <translation>Wykryto jednostkę cykliczną.</translation>
    </message>
    <message>
        <source>Unsupported XML version.</source>
        <translation>Nieobsługiwana wersja XML.</translation>
    </message>
    <message>
        <source>Unexpected &apos;</source>
        <translation>Niespodziewany &apos;</translation>
    </message>
    <message>
        <source>Invalid entity value.</source>
        <translation>Wartość jednostki jest nieprawidłowa.</translation>
    </message>
    <message>
        <source>Encoding %1 is unsupported</source>
        <translation>Kodowanie %1 nie jest obsługiwane</translation>
    </message>
    <message>
        <source>NDATA in parameter entity declaration.</source>
        <translation>NDATA w deklaracji jednostki parametru.</translation>
    </message>
</context>
<context>
    <name>QProcess</name>
    <message>
        <source>Error writing to process</source>
        <translation>Błąd zapisu do przetworzenia</translation>
    </message>
    <message>
        <source>Resource error (fork failure): %1</source>
        <translation>Błąd zasobów (awaria wideł): %1</translation>
    </message>
    <message>
        <source>Error reading from process</source>
        <translation>Błąd odczytu z procesu</translation>
    </message>
    <message>
        <source>Process failed to start: %1</source>
        <translation>Nie można rozpocząć procesu: %1</translation>
    </message>
    <message>
        <source>Could not open input redirection for reading</source>
        <translation>Nie można otworzyć przekierowania wejściowego do odczytu</translation>
    </message>
    <message>
        <source>Process failed to start (spawned process exited with code 127)</source>
        <translation>Proces nie został uruchomiony (proces spawnowania zakończony kodem 127)</translation>
    </message>
    <message>
        <source>No program defined</source>
        <translation>Nie zdefiniowano programu</translation>
    </message>
    <message>
        <source>Could not open output redirection for writing</source>
        <translation>Nie można otworzyć przekierowania danych wyjściowych do zapisu</translation>
    </message>
    <message>
        <source>Process operation timed out</source>
        <translation>Upłynął limit czasu operacji procesu</translation>
    </message>
    <message>
        <source>Process crashed</source>
        <translation>Proces się zawiesił</translation>
    </message>
</context>
<context>
    <name>QNativeSocketEngine</name>
    <message>
        <source>The proxy type is invalid for this operation</source>
        <translation>Typ proxy jest nieprawidłowy dla tej operacji</translation>
    </message>
    <message>
        <source>Network operation timed out</source>
        <translation>Upłynął limit czasu działania sieci</translation>
    </message>
    <message>
        <source>The remote host closed the connection</source>
        <translation>Zdalne połączenie z hostem zamknięte</translation>
    </message>
    <message>
        <source>Invalid socket descriptor</source>
        <translation>Deskryptor gniazda jest nieprawidłowy</translation>
    </message>
    <message>
        <source>Host unreachable</source>
        <translation>Host jest niedostępny</translation>
    </message>
    <message>
        <source>Protocol type not supported</source>
        <translation>Typ protokołu nie jest obsługiwany</translation>
    </message>
    <message>
        <source>Datagram was too large to send</source>
        <translation>Datagram był zbyt duży, aby wysłać</translation>
    </message>
    <message>
        <source>Attempt to use IPv6 socket on a platform with no IPv6 support</source>
        <translation>Spróbuj użyć gniazda IPv6 na platformie, która nie obsługuje IPv6</translation>
    </message>
    <message>
        <source>Unable to receive a message</source>
        <translation>Nie można odebrać wiadomości</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Odmowa uprawnień</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Połączenie odrzucone</translation>
    </message>
    <message>
        <source>Unable to write</source>
        <translation>Niemożliwe do napisania</translation>
    </message>
    <message>
        <source>Another socket is already listening on the same port</source>
        <translation>Inne gniazdo już nasłuchuje na tym samym porcie</translation>
    </message>
    <message>
        <source>Unable to send a message</source>
        <translation>Nie można wysłać wiadomości</translation>
    </message>
    <message>
        <source>The bound address is already in use</source>
        <translation>Adres powiązany jest już w użyciu</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Przekroczono limit czasu połączenia</translation>
    </message>
    <message>
        <source>Network error</source>
        <translation>Błąd sieci</translation>
    </message>
    <message>
        <source>Unsupported socket operation</source>
        <translation>Nieobsługiwane działanie gniazda</translation>
    </message>
    <message>
        <source>Operation on non-socket</source>
        <translation>Działanie w trybie innym niż gniazdo</translation>
    </message>
    <message>
        <source>Unable to initialize broadcast socket</source>
        <translation>Nie można zainicjować gniazda rozgłoszeniowego</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
    <message>
        <source>Unable to initialize non-blocking socket</source>
        <translation>Nie można zainicjować gniazda nieblokującego</translation>
    </message>
    <message>
        <source>The address is protected</source>
        <translation>Adres jest chroniony</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Sieć nieosiągalna</translation>
    </message>
    <message>
        <source>The address is not available</source>
        <translation>Adres jest niedostępny</translation>
    </message>
    <message>
        <source>Temporary error</source>
        <translation>Tymczasowy błąd</translation>
    </message>
    <message>
        <source>Out of resources</source>
        <translation>Brak zasobów</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFtpBackend</name>
    <message>
        <source>No suitable proxy found</source>
        <translation>Nie znaleziono odpowiedniego serwera proxy</translation>
    </message>
    <message>
        <source>Error while downloading %1: %2</source>
        <translation>Błąd podczas pobierania %1&#xa0;: %2</translation>
    </message>
    <message>
        <source>Error while uploading %1: %2</source>
        <translation>Błąd podczas przesyłania %1&#xa0;: %2</translation>
    </message>
    <message>
        <source>Cannot open %1: is a directory</source>
        <translation>Nie można otworzyć %1: jest katalogiem</translation>
    </message>
    <message>
        <source>Logging in to %1 failed: authentication required</source>
        <translation>Logowanie do %1 nie powiodło się: wymagane uwierzytelnienie</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyHttpImpl</name>
    <message>
        <source>No suitable proxy found</source>
        <translation>Nie znaleziono odpowiedniego serwera proxy</translation>
    </message>
    <message>
        <source>Operation canceled</source>
        <translation>Operacja anulowana</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyHttpImplPrivate</name>
    <message>
        <source>No suitable proxy found</source>
        <translation>Nie znaleziono odpowiedniego serwera proxy</translation>
    </message>
</context>
<context>
    <name>QDockWidget</name>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>Float</source>
        <translation>Ruchomy</translation>
    </message>
    <message>
        <source>Undocks and re-attaches the dock widget</source>
        <translation>Odblokowuje i ponownie dołącza widżet dokowania</translation>
    </message>
    <message>
        <source>Closes the dock widget</source>
        <translation>Zamyka widget dokowania</translation>
    </message>
</context>
<context>
    <name>QAccessibleActionInterface</name>
    <message>
        <source>Press</source>
        <translation>Nacisnij</translation>
    </message>
    <message>
        <source>Shows the menu</source>
        <translation>Wyświetla menu</translation>
    </message>
    <message>
        <source>Scrolls to the left</source>
        <translation>Przewijanie w lewo</translation>
    </message>
    <message>
        <source>Scroll Down</source>
        <translation>Przewiń w dół</translation>
    </message>
    <message>
        <source>Scroll Left</source>
        <translation>Przewiń w lewo</translation>
    </message>
    <message>
        <source>Goes back a page</source>
        <translation>Powróć do poprzedniej strony</translation>
    </message>
    <message>
        <source>Triggers the action</source>
        <translation>Wyzwala akcję</translation>
    </message>
    <message>
        <source>Increase</source>
        <translation>Zwiększanie</translation>
    </message>
    <message>
        <source>Toggle</source>
        <translation>Przełącznik</translation>
    </message>
    <message>
        <source>Toggles the state</source>
        <translation>Przełącza stan</translation>
    </message>
    <message>
        <source>Scrolls up</source>
        <translation>Przewijanie w górę</translation>
    </message>
    <message>
        <source>Scrolls down</source>
        <translation>Przewija w dół</translation>
    </message>
    <message>
        <source>Scroll Up</source>
        <translation>Przewiń do góry</translation>
    </message>
    <message>
        <source>Goes to the next page</source>
        <translation>Przejdź do następnej strony</translation>
    </message>
    <message>
        <source>Scrolls to the right</source>
        <translation>Przewijanie w prawo</translation>
    </message>
    <message>
        <source>Increase the value</source>
        <translation>Zwiększ wartość</translation>
    </message>
    <message>
        <source>Decrease the value</source>
        <translation>Zmniejsz wartość</translation>
    </message>
    <message>
        <source>Decrease</source>
        <translation>Zmniejszanie</translation>
    </message>
    <message>
        <source>Scroll Right</source>
        <translation>Przewiń w prawo</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>Poprzednia strona</translation>
    </message>
    <message>
        <source>Sets the focus</source>
        <translation>Ustawia ostrość</translation>
    </message>
    <message>
        <source>SetFocus</source>
        <translation>UstawićOstrość</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>Następna Strona</translation>
    </message>
    <message>
        <source>ShowMenu</source>
        <translation>PokażMenu</translation>
    </message>
</context>
<context>
    <name>QSocks5SocketEngine</name>
    <message>
        <source>Network operation timed out</source>
        <translation>Upłynął limit czasu działania sieci</translation>
    </message>
    <message>
        <source>Connection to proxy closed prematurely</source>
        <translation>Połączenie z serwerem proxy zostało przedwcześnie zamknięte</translation>
    </message>
    <message>
        <source>Proxy authentication failed: %1</source>
        <translation>Niepowodzenie uwierzytelnienia serwera proxy: %1</translation>
    </message>
    <message>
        <source>Proxy authentication failed</source>
        <translation>Uwierzytelnianie serwera proxy nie powiodło się</translation>
    </message>
    <message>
        <source>General SOCKSv5 server failure</source>
        <translation>Ogólna awaria serwera SOCKSv5</translation>
    </message>
    <message>
        <source>Unknown SOCKSv5 proxy error code 0x%1</source>
        <translation>Nieznany kod błędu proxy SOCKSv5 0x%1</translation>
    </message>
    <message>
        <source>Connection not allowed by SOCKSv5 server</source>
        <translation>Połączenie niedozwolone przez serwer SOCKSv5</translation>
    </message>
    <message>
        <source>SOCKSv5 command not supported</source>
        <translation>Komenda SOCKSv5 nie jest obsługiwana</translation>
    </message>
    <message>
        <source>Connection to proxy timed out</source>
        <translation>Upłynął limit czasu połączenia z serwerem proxy</translation>
    </message>
    <message>
        <source>Proxy host not found</source>
        <translation>Nie znaleziono hosta proxy</translation>
    </message>
    <message>
        <source>TTL expired</source>
        <translation>TTL wygasło</translation>
    </message>
    <message>
        <source>Address type not supported</source>
        <translation>Typ adresu nie jest obsługiwany</translation>
    </message>
    <message>
        <source>Connection to proxy refused</source>
        <translation>Odmówiono połączenia z serwerem proxy</translation>
    </message>
    <message>
        <source>SOCKS version 5 protocol error</source>
        <translation>Błąd protokołu SOCKS wersja 5</translation>
    </message>
</context>
<context>
    <name>QDnsLookupRunnable</name>
    <message>
        <source>No hostname given</source>
        <translation>Nie podano nazwy hosta</translation>
    </message>
    <message>
        <source>Server failure</source>
        <translation>Awaria serwera</translation>
    </message>
    <message>
        <source>Invalid text record</source>
        <translation>Niepoprawny rekord tekstowy</translation>
    </message>
    <message>
        <source>Invalid mail exchange record</source>
        <translation>Nieprawidłowy rekord wymiany poczty</translation>
    </message>
    <message>
        <source>Invalid canonical name record</source>
        <translation>Nieprawidłowy kanoniczny rekord nazwy</translation>
    </message>
    <message>
        <source>Invalid service record</source>
        <translation>Nieprawidłowy rekord usługi</translation>
    </message>
    <message>
        <source>Non existent domain</source>
        <translation>Nieistniejąca domena</translation>
    </message>
    <message>
        <source>Server could not process query</source>
        <translation>Serwer nie może przetworzyć zapytania</translation>
    </message>
    <message>
        <source>IPv6 addresses for nameservers is currently not supported</source>
        <translation>Adresy IPv6 dla serwerów nazw nie są obecnie obsługiwane</translation>
    </message>
    <message>
        <source>Not yet supported on Android</source>
        <translation>Jeszcze nieobsługiwany w systemie Android</translation>
    </message>
    <message>
        <source>Resolver functions not found</source>
        <translation>Nie znaleziono funkcji Resolver</translation>
    </message>
    <message>
        <source>Invalid domain name</source>
        <translation>Nieprawidłowa nazwa domeny</translation>
    </message>
    <message>
        <source>Invalid pointer record</source>
        <translation>Nieprawidłowy rekord wskaźnika</translation>
    </message>
    <message>
        <source>Invalid name server record</source>
        <translation>Niepoprawny rekord serwera nazw</translation>
    </message>
    <message>
        <source>Resolver library can&apos;t be loaded: No runtime library loading support</source>
        <translation>Nie można załadować biblioteki Resolver: Brak obsługi ładowania biblioteki wykonawczej</translation>
    </message>
    <message>
        <source>Server refused to answer</source>
        <translation>Serwer odmówił odpowiedzi</translation>
    </message>
    <message>
        <source>Invalid hostname</source>
        <translation>Nieprawidłowa nazwa hosta</translation>
    </message>
    <message>
        <source>Could not expand domain name</source>
        <translation>Nie można rozwinąć nazwy domeny</translation>
    </message>
    <message>
        <source>Resolver initialization failed</source>
        <translation>Inicjalizacja Resolver nie powiodła się</translation>
    </message>
    <message>
        <source>Invalid reply received</source>
        <translation>Otrzymano niepoprawną odpowiedź</translation>
    </message>
    <message>
        <source>Invalid IPv6 address record</source>
        <translation>Nieprawidłowy rekord adresu IPv6</translation>
    </message>
    <message>
        <source>Invalid IPv4 address record</source>
        <translation>Nieprawidłowy rekord adresu IPv4</translation>
    </message>
</context>
<context>
    <name>QRegExp</name>
    <message>
        <source>invalid category</source>
        <translation>niepoprawna kategoria</translation>
    </message>
    <message>
        <source>bad lookahead syntax</source>
        <translation>składnia lookahead jest nieprawidłowa</translation>
    </message>
    <message>
        <source>no error occurred</source>
        <translation>nie wystąpił błąd</translation>
    </message>
    <message>
        <source>missing left delim</source>
        <translation>brakuje lewego ograniczenia</translation>
    </message>
    <message>
        <source>bad char class syntax</source>
        <translation>zła składnia klasy char</translation>
    </message>
    <message>
        <source>disabled feature used</source>
        <translation>używana funkcja wyłączona</translation>
    </message>
    <message>
        <source>invalid octal value</source>
        <translation>niepoprawna wartość ósemkowa</translation>
    </message>
    <message>
        <source>bad repetition syntax</source>
        <translation>zła składnia powtórzeń</translation>
    </message>
    <message>
        <source>met internal limit</source>
        <translation>osiągnięty wewnętrzny limit</translation>
    </message>
    <message>
        <source>invalid interval</source>
        <translation>niepoprawny interwał</translation>
    </message>
    <message>
        <source>unexpected end</source>
        <translation>nieoczekiwany koniec</translation>
    </message>
    <message>
        <source>lookbehinds not supported, see QTBUG-2371</source>
        <translation>funkcja lookbehinds nie jest obsługiwana, patrz raport o błędach QTBUG-2371</translation>
    </message>
</context>
<context>
    <name>QDialog</name>
    <message>
        <source>What&apos;s This?</source>
        <translation>Co to jest?</translation>
    </message>
</context>
<context>
    <name>QWhatsThisAction</name>
    <message>
        <source>What&apos;s This?</source>
        <translation>Co to jest?</translation>
    </message>
</context>
<context>
    <name>QFtp</name>
    <message>
        <source>Listing directory failed:
%1</source>
        <translation>Lista folderów nie powiodła się:
%1</translation>
    </message>
    <message>
        <source>Creating directory failed:
%1</source>
        <translation>Nie udało się utworzyć folderu:
%1</translation>
    </message>
    <message>
        <source>Not connected</source>
        <translation>Niepołączony</translation>
    </message>
    <message>
        <source>Connection refused for data connection</source>
        <translation>Odmowa połączenia dla transmisji danych</translation>
    </message>
    <message>
        <source>Login failed:
%1</source>
        <translation>Logowanie nie powiodło się:
%1</translation>
    </message>
    <message>
        <source>Downloading file failed:
%1</source>
        <translation>Pobieranie pliku nie powiodło się:
%1</translation>
    </message>
    <message>
        <source>Connection timed out to host %1</source>
        <translation>Przekroczono limit czasu połączenia z hostem %1</translation>
    </message>
    <message>
        <source>Connected to host %1</source>
        <translation>Połączenie z hostem %1</translation>
    </message>
    <message>
        <source>Connecting to host failed:
%1</source>
        <translation>Połączenie z hostem nie powiodło się:
%1</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation>Nie znaleziono hosta %1</translation>
    </message>
    <message>
        <source>Uploading file failed:
%1</source>
        <translation>Przesyłanie pliku nie powiodło się:
%1</translation>
    </message>
    <message>
        <source>Changing directory failed:
%1</source>
        <translation>Nie udało się zmienić folderu:
%1</translation>
    </message>
    <message>
        <source>Data Connection refused</source>
        <translation>Połączenie danych zostało odrzucone</translation>
    </message>
    <message>
        <source>Removing directory failed:
%1</source>
        <translation>Usunięcie katalogu nie powiodło się:
%1</translation>
    </message>
    <message>
        <source>Connection refused to host %1</source>
        <translation>Odmowa obsługi połączenia %1</translation>
    </message>
    <message>
        <source>Removing file failed:
%1</source>
        <translation>Usunięcie pliku nie powiodło się: 
%1</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
    <message>
        <source>Connection closed</source>
        <translation>Połączenie zamknięte</translation>
    </message>
</context>
<context>
    <name>QDB2Driver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Nie można zatwierdzić transakcji</translation>
    </message>
    <message>
        <source>Unable to set autocommit</source>
        <translation>Nie można ustawić automatycznego zatwierdzania</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>Nie można połączyć</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Nie można przywrócić transakcji</translation>
    </message>
</context>
<context>
    <name>QIBaseDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Nie można zatwierdzić transakcji</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>Nie można rozpocząć transakcji</translation>
    </message>
    <message>
        <source>Error opening database</source>
        <translation>Błąd podczas otwierania bazy danych</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Nie można przywrócić transakcji</translation>
    </message>
</context>
<context>
    <name>QIBaseResult</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Nie można zatwierdzić transakcji</translation>
    </message>
    <message>
        <source>Unable to open BLOB</source>
        <translation>Nie można otworzyć BLOB</translation>
    </message>
    <message>
        <source>Could not describe statement</source>
        <translation>Nie udało się opisać wyrażenia</translation>
    </message>
    <message>
        <source>Could not describe input statement</source>
        <translation>Nie można opisać informacji wejściowej</translation>
    </message>
    <message>
        <source>Could not allocate statement</source>
        <translation>Nie można przydzielić żądania</translation>
    </message>
    <message>
        <source>Unable to write BLOB</source>
        <translation>Nie można napisać BLOB</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>Nie można rozpocząć transakcji</translation>
    </message>
    <message>
        <source>Unable to close statement</source>
        <translation>Nie można zamknąć żądania</translation>
    </message>
    <message>
        <source>Could not get query info</source>
        <translation>Nie można uzyskać informacji o żądaniu</translation>
    </message>
    <message>
        <source>Could not find array</source>
        <translation>Nie można znaleźć tabeli</translation>
    </message>
    <message>
        <source>Could not get array data</source>
        <translation>Nie można znaleźć tabeli danych</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>Nie można wykonać zapytania</translation>
    </message>
    <message>
        <source>Could not prepare statement</source>
        <translation>Nie udało się przygotować wyrażenia</translation>
    </message>
    <message>
        <source>Could not fetch next item</source>
        <translation>Nie można pobrać następnego elementu</translation>
    </message>
    <message>
        <source>Could not get statement info</source>
        <translation>Nie można znaleźć informacji o wyrażeniu</translation>
    </message>
    <message>
        <source>Unable to create BLOB</source>
        <translation>Nie można utworzyć BLOBa</translation>
    </message>
    <message>
        <source>Unable to read BLOB</source>
        <translation>Nie można odczytać BLOB</translation>
    </message>
</context>
<context>
    <name>QMYSQLDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Nie można zatwierdzić transakcji</translation>
    </message>
    <message>
        <source>Unable to open database &apos;%1&apos;</source>
        <translation>Nie można otworzyć bazy danyche &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Unable to open database &apos;</source>
        <translation>Nie można otworzyć bazy danych &apos;</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>Nie można połączyć</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Nie można przywrócić transakcji</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>Nie można rozpocząć transakcji</translation>
    </message>
</context>
<context>
    <name>QOCIDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Nie można zatwierdzić transakcji</translation>
    </message>
    <message>
        <source>Unable to initialize</source>
        <translation>Niemożliwy do zainicjowania</translation>
    </message>
    <message>
        <source>Unable to logon</source>
        <translation>Nie można się zalogować</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Nie można przywrócić transakcji</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>Nie można rozpocząć transakcji</translation>
    </message>
</context>
<context>
    <name>QODBCDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Nie można zatwierdzić transakcji</translation>
    </message>
    <message>
        <source>Unable to enable autocommit</source>
        <translation>Nie można włączyć automatycznego zatwierdzania</translation>
    </message>
    <message>
        <source>Unable to disable autocommit</source>
        <translation>Nie można wyłączyć automatycznego zatwierdzania</translation>
    </message>
    <message>
        <source>Unable to connect - Driver doesn&apos;t support all functionality required</source>
        <translation>Nie można się połączyć - sterownik nie obsługuje wszystkich wymaganych funkcji</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>Nie można połączyć</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Nie można przywrócić transakcji</translation>
    </message>
</context>
<context>
    <name>QSQLite2Driver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Nie można zatwierdzić transakcji</translation>
    </message>
    <message>
        <source>Error opening database</source>
        <translation>Błąd podczas otwierania bazy danych</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Nie można przywrócić transakcji</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>Nie można rozpocząć transakcji</translation>
    </message>
</context>
<context>
    <name>QSQLiteDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Nie można zatwierdzić transakcji</translation>
    </message>
    <message>
        <source>Error closing database</source>
        <translation>Błąd zamykania bazy danych</translation>
    </message>
    <message>
        <source>Error opening database</source>
        <translation>Błąd podczas otwierania bazy danych</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Nie można przywrócić transakcji</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>Nie można rozpocząć transakcji</translation>
    </message>
</context>
<context>
    <name>QAbstractSocket</name>
    <message>
        <source>Host not found</source>
        <translation>Host nieznaleziony</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Połączenie odrzucone</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Przekroczono limit czasu połączenia</translation>
    </message>
    <message>
        <source>Trying to connect while connection is in progress</source>
        <translation>Próba nawiązania połączenia w trakcie połączenia</translation>
    </message>
    <message>
        <source>Socket is not connected</source>
        <translation>Gniazdo nie jest podłączone</translation>
    </message>
    <message>
        <source>Socket operation timed out</source>
        <translation>Upłynął limit czasu operacji gniazda</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Sieć nieosiągalna</translation>
    </message>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>Operacja na gnieździe nie jest obsługiwana</translation>
    </message>
</context>
<context>
    <name>QHostInfoAgent</name>
    <message>
        <source>Host not found</source>
        <translation>Host nieznaleziony</translation>
    </message>
    <message>
        <source>No host name given</source>
        <translation>Nie podano nazwy hosta</translation>
    </message>
    <message>
        <source>Unknown address type</source>
        <translation>Nieznany typ adresu</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
    <message>
        <source>Invalid hostname</source>
        <translation>Nieprawidłowa nazwa hosta</translation>
    </message>
    <message>
        <source>Unknown error (%1)</source>
        <translation>Nieznany błąd (%1)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Image type not supported</source>
        <translation>Typ obrazu nie jest obsługiwany</translation>
    </message>
    <message>
        <source>Image mHeader read failed</source>
        <translation>Odczyt obrazu mHeader nie powiódł się</translation>
    </message>
    <message>
        <source>Seek file/device for image read failed</source>
        <translation>Nie można znaleźć czytnika plików / obrazów</translation>
    </message>
    <message>
        <source>Could not read image data</source>
        <translation>Nie można odczytać danych obrazu</translation>
    </message>
    <message>
        <source>Could not reset to read data</source>
        <translation>Nie można zresetować, aby odczytać dane</translation>
    </message>
    <message>
        <source>Could not read footer</source>
        <translation>Nie można odczytać stopki</translation>
    </message>
    <message>
        <source>Image dpeth not valid</source>
        <translation>Głębia obrazu jest nieprawidłowa</translation>
    </message>
    <message>
        <source>Sequential device (eg socket) for image read not supported</source>
        <translation>Sekwencyjne urządzenie (np. gniazdo) do odczytu obrazu nie jest obsługiwane</translation>
    </message>
    <message>
        <source>Image type (non-TrueVision 2.0) not supported</source>
        <translation>Typ obrazu (inny niż TrueVision 2.0) nie jest obsługiwany</translation>
    </message>
    <message>
        <source>Could not seek to image read footer</source>
        <translation>Nie można znaleźć stopki do odczytu obrazu</translation>
    </message>
</context>
<context>
    <name>QTgaFile</name>
    <message>
        <source>Image type not supported</source>
        <translation>Typ obrazu nie jest obsługiwany</translation>
    </message>
    <message>
        <source>Image header read failed</source>
        <translation>Odczyt nagłówka obrazu nie powiódł się</translation>
    </message>
    <message>
        <source>Seek file/device for image read failed</source>
        <translation>Nie można znaleźć czytnika plików / obrazów</translation>
    </message>
    <message>
        <source>Could not read image data</source>
        <translation>Nie można odczytać danych obrazu</translation>
    </message>
    <message>
        <source>Could not reset to read data</source>
        <translation>Nie można zresetować, aby odczytać dane</translation>
    </message>
    <message>
        <source>Image depth not valid</source>
        <translation>Głębia obrazu jest nieprawidłowa</translation>
    </message>
    <message>
        <source>Could not read footer</source>
        <translation>Nie można odczytać stopki</translation>
    </message>
    <message>
        <source>Sequential device (eg socket) for image read not supported</source>
        <translation>Sekwencyjne urządzenie (np. gniazdo) do odczytu obrazu nie jest obsługiwane</translation>
    </message>
    <message>
        <source>Image type (non-TrueVision 2.0) not supported</source>
        <translation>Typ obrazu (inny niż TrueVision 2.0) nie jest obsługiwany</translation>
    </message>
    <message>
        <source>Could not seek to image read footer</source>
        <translation>Nie można znaleźć stopki do odczytu obrazu</translation>
    </message>
</context>
<context>
    <name>QLibrary</name>
    <message>
        <source>not a dynamic library</source>
        <translation>nie jest dynamiczną biblioteką</translation>
    </message>
    <message>
        <source>file too small</source>
        <translation>zbyt mały plik</translation>
    </message>
    <message>
        <source>Cannot unload library %1: %2</source>
        <translation>Nie można zwolnić biblioteki %1 : %2</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a valid Mach-O binary (%2)</source>
        <translation>&apos;%1&apos; nie jest prawidłowym binarnym Mach-O (%2)</translation>
    </message>
    <message>
        <source>Cannot load library %1: %2</source>
        <translation>Nie można załadować biblioteki %1&#xa0;: %2</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not a Qt plugin</source>
        <translation>&apos;%1&apos; nie jest wtyczką Qt</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not an ELF object (%2)</source>
        <translation>&apos;%1&apos; nie jest obiektem ELF (%2)</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (%2.%3.%4) [%5]</source>
        <translation>Wtyczka &apos;%1&apos; korzysta z niekompatybilnej biblioteki Qt. (%2.%3.%4) [%5]</translation>
    </message>
    <message>
        <source>Cannot resolve symbol &quot;%1&quot; in %2: %3</source>
        <translation>Nie można rozwiązać symbolu &quot;%1&quot; dans %2&#xa0;: %3</translation>
    </message>
    <message>
        <source>Plugin verification data mismatch in &apos;%1&apos;</source>
        <translation>Niezgodność danych weryfikacyjnych wtyczki w &apos;%1&apos;</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is an invalid ELF object (%2)</source>
        <translation>&apos;%1&apos; jest nieprawidłowym obiektem ELF (%2)</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (Cannot mix debug and release libraries.)</source>
        <translation>Wtyczka &apos;%1&apos; korzysta z niekompatybilnej biblioteki Qt. (Nie można łączyć bibliotek debugowania i wydań.)</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is not an ELF object</source>
        <translation>&apos;%1&apos; nie jest obiektem ELF</translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; is not a valid Qt plugin.</source>
        <translation>Plik &apos;%1&apos; nie jest prawidłową wtyczką Qt.</translation>
    </message>
    <message>
        <source>The shared library was not found.</source>
        <translation>Udostępniona biblioteka nie została znaleziona.</translation>
    </message>
    <message>
        <source>wrong architecture</source>
        <translation>niewłaściwa architektura</translation>
    </message>
    <message>
        <source>file is corrupt</source>
        <translation>plik jest uszkodzony</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
    <message>
        <source>no suitable architecture in fat binary</source>
        <translation>brak odpowiedniej architektury w pliku binarnym</translation>
    </message>
    <message>
        <source>invalid magic %1</source>
        <translation>magiczna liczba %1 jest nieprawidłowa</translation>
    </message>
</context>
<context>
    <name>QSQLiteResult</name>
    <message>
        <source>Unable to execute multiple statements at a time</source>
        <translation>Nie można wykonać wielu instrukcji jednocześnie</translation>
    </message>
    <message>
        <source>Unable to fetch row</source>
        <translation>Nie można pobrać linii</translation>
    </message>
    <message>
        <source>No query</source>
        <translation>Bez zapytania</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Nie można wykonać instrukcji</translation>
    </message>
    <message>
        <source>Unable to bind parameters</source>
        <translation>Nie można dołączyć parametrów</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>Nie można zresetować wyrażenia</translation>
    </message>
    <message>
        <source>Parameter count mismatch</source>
        <translation>Niepoprawna liczba parametrów</translation>
    </message>
</context>
<context>
    <name>QXml</name>
    <message>
        <source>unparsed entity reference in wrong context</source>
        <translation>odniesienie do jednostki, która nie została przeanalizowana w złym kontekście</translation>
    </message>
    <message>
        <source>external parsed general entity reference not allowed in DTD</source>
        <translation>zewnętrzne odwołanie do ogólnej jednostki odniesienia jest niedozwolone w DTD</translation>
    </message>
    <message>
        <source>wrong value for standalone declaration</source>
        <translation>zła wartość dla samodzielnej deklaracji</translation>
    </message>
    <message>
        <source>encoding declaration or standalone declaration expected while reading the XML declaration</source>
        <translation>podczas odczytu deklaracji XML oczekiwana jest deklaracja kodowania lub deklaracja samodzielna</translation>
    </message>
    <message>
        <source>no error occurred</source>
        <translation>nie wystąpił błąd</translation>
    </message>
    <message>
        <source>error occurred while parsing reference</source>
        <translation>Wystąpił błąd podczas analizowania odwołania</translation>
    </message>
    <message>
        <source>standalone declaration expected while reading the XML declaration</source>
        <translation>oczekiwana „samodzielna” deklaracja podczas odczytu deklaracji XML</translation>
    </message>
    <message>
        <source>invalid name for processing instruction</source>
        <translation>nazwa instrukcji jest nieprawidłowa</translation>
    </message>
    <message>
        <source>error triggered by consumer</source>
        <translation>błąd wywołany przez konsumenta</translation>
    </message>
    <message>
        <source>error occurred while parsing element</source>
        <translation>Wystąpił błąd podczas analizowania elementu</translation>
    </message>
    <message>
        <source>unexpected character</source>
        <translation>nieoczekiwany charakter</translation>
    </message>
    <message>
        <source>tag mismatch</source>
        <translation>niedopasowanie tagu</translation>
    </message>
    <message>
        <source>error occurred while parsing content</source>
        <translation>Wystąpił błąd podczas analizowania zawartości</translation>
    </message>
    <message>
        <source>error occurred while parsing comment</source>
        <translation>Wystąpił błąd podczas analizowania komentarza</translation>
    </message>
    <message>
        <source>internal general entity reference not allowed in DTD</source>
        <translation>odniesienie do wewnętrznego podmiotu ogólnego nieupoważnionego w DTD</translation>
    </message>
    <message>
        <source>recursive entities</source>
        <translation>podmioty rekurencyjne</translation>
    </message>
    <message>
        <source>more than one document type definition</source>
        <translation>więcej niż jedna definicja typu dokumentu</translation>
    </message>
    <message>
        <source>version expected while reading the XML declaration</source>
        <translation>oczekiwana wersja podczas czytania deklaracji XML</translation>
    </message>
    <message>
        <source>letter is expected</source>
        <translation>list jest oczekiwany</translation>
    </message>
    <message>
        <source>unexpected end of file</source>
        <translation>nieoczekiwany koniec pliku</translation>
    </message>
    <message>
        <source>external parsed general entity reference not allowed in attribute value</source>
        <translation>odwołanie do zewnętrznego analizowanego obiektu ogólnego nie jest dozwolone w wartości atrybutu</translation>
    </message>
    <message>
        <source>error in the text declaration of an external entity</source>
        <translation>błąd w deklaracji tekstowej podmiotu zewnętrznego</translation>
    </message>
    <message>
        <source>error occurred while parsing document type definition</source>
        <translation>Wystąpił błąd podczas analizowania definicji typu dokumentu</translation>
    </message>
</context>
<context>
    <name>QSystemSemaphore</name>
    <message>
        <source>%1: does not exist</source>
        <translation>%1: nie istnieje</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: już istnieje</translation>
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation>%1: nieznany błąd %2</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: odmowa dostępu</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: brak zasobów</translation>
    </message>
</context>
<context>
    <name>QCommandLineParser</name>
    <message>
        <source>Unknown options: %1.</source>
        <translation>Nieznane opcje: %1.</translation>
    </message>
    <message>
        <source>Unknown option &apos;%1&apos;.</source>
        <translation>Nieznana opcja &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>[options]</source>
        <translation>[opcje]</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Opcje:</translation>
    </message>
    <message>
        <source>Usage: %1</source>
        <translation>Użycie: %1</translation>
    </message>
    <message>
        <source>Unexpected value after &apos;%1&apos;.</source>
        <translation>Nieoczekiwana wartość po &apos;%1&apos;.</translation>
    </message>
    <message>
        <source>Displays version information.</source>
        <translation>Wyświetla wersję informacyjną.</translation>
    </message>
    <message>
        <source>Arguments:</source>
        <translation>Argumenty:</translation>
    </message>
    <message>
        <source>Displays this help.</source>
        <translation>Wyświetl tę pomoc.</translation>
    </message>
    <message>
        <source>Missing value after &apos;%1&apos;.</source>
        <translation>Brak wartości po &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>Data corrupted</source>
        <translation>Dane są uszkodzone</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation>Nie znaleziono hosta %1</translation>
    </message>
    <message>
        <source>Host requires authentication</source>
        <translation>Host wymaga uwierzytelnienia</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Połączenie odrzucone</translation>
    </message>
    <message>
        <source>Unknown protocol specified</source>
        <translation>Określono nieznany protokół</translation>
    </message>
    <message>
        <source>Proxy requires authentication</source>
        <translation>Serwer proxy wymaga uwierzytelnienia</translation>
    </message>
    <message>
        <source>SSL handshake failed</source>
        <translation>Uzgadnianie SSL nie powiodło się</translation>
    </message>
    <message>
        <source>Connection closed</source>
        <translation>Połączenie zamknięte</translation>
    </message>
</context>
<context>
    <name>QUnicodeControlCharacterMenu</name>
    <message>
        <source>RLE Start of right-to-left embedding</source>
        <translation>RLE Rozpoczęcie osadzania od prawej do lewej</translation>
    </message>
    <message>
        <source>ZWSP Zero width space</source>
        <translation>ZWSP Przestrzeń zerowej szerokości</translation>
    </message>
    <message>
        <source>LRI Left-to-right isolate</source>
        <translation>LRI Izolat od lewej do prawej</translation>
    </message>
    <message>
        <source>Insert Unicode control character</source>
        <translation>Wstawianie znaku sterującego Unicode</translation>
    </message>
    <message>
        <source>LRO Start of left-to-right override</source>
        <translation>LRO Początek zastąpienia od lewej do prawej</translation>
    </message>
    <message>
        <source>LRE Start of left-to-right embedding</source>
        <translation>LRE Początek osadzania od lewej do prawej</translation>
    </message>
    <message>
        <source>RLI Right-to-left isolate</source>
        <translation>RLI Izolat od prawej do lewej</translation>
    </message>
    <message>
        <source>RLM Right-to-left mark</source>
        <translation>RLM Oznaczenie od prawej do lewej</translation>
    </message>
    <message>
        <source>PDF Pop directional formatting</source>
        <translation>PDF Formatowanie kierunkowe pop</translation>
    </message>
    <message>
        <source>ZWNJ Zero width non-joiner</source>
        <translation>ZWNJ Łącznik o zerowej szerokości</translation>
    </message>
    <message>
        <source>RLO Start of right-to-left override</source>
        <translation>RLO Rozpoczęcie nadpisywania od prawej do lewej</translation>
    </message>
    <message>
        <source>PDI Pop directional isolate</source>
        <translation>PDI Izolat kierunkowy Pop</translation>
    </message>
    <message>
        <source>ZWJ Zero width joiner</source>
        <translation>Łącznik ZWJ o zerowej szerokości</translation>
    </message>
    <message>
        <source>LRM Left-to-right mark</source>
        <translation>LRM znacznika od lewej do prawej</translation>
    </message>
    <message>
        <source>FSI First strong isolate</source>
        <translation>FSI Pierwszy silny izolat</translation>
    </message>
</context>
<context>
    <name>QJsonParseError</name>
    <message>
        <source>invalid UTF8 string</source>
        <translation>nieprawidłowy ciąg UTF8</translation>
    </message>
    <message>
        <source>unterminated array</source>
        <translation>niezakończona tabela</translation>
    </message>
    <message>
        <source>unterminated object</source>
        <translation>niezakończony obiekt</translation>
    </message>
    <message>
        <source>no error occurred</source>
        <translation>nie wystąpił błąd</translation>
    </message>
    <message>
        <source>unterminated string</source>
        <translation>ciąg nieskończony</translation>
    </message>
    <message>
        <source>garbage at the end of the document</source>
        <translation>nieprawidłowe dane na końcu dokumentu</translation>
    </message>
    <message>
        <source>invalid termination by number</source>
        <translation>zakończenie numerem jest nieprawidłowe</translation>
    </message>
    <message>
        <source>missing value separator</source>
        <translation>brak separatora wartości</translation>
    </message>
    <message>
        <source>illegal number</source>
        <translation>nielegalny numer</translation>
    </message>
    <message>
        <source>invalid escape sequence</source>
        <translation>niepoprawna sekwencja wyjścia</translation>
    </message>
    <message>
        <source>missing name separator</source>
        <translation>brak separatora nazw</translation>
    </message>
    <message>
        <source>too large document</source>
        <translation>zbyt duży dokument</translation>
    </message>
    <message>
        <source>object is missing after a comma</source>
        <translation>po przecinku brakuje obiektu</translation>
    </message>
    <message>
        <source>too deeply nested document</source>
        <translation>dokument jest zagnieżdżony zbyt głęboko</translation>
    </message>
    <message>
        <source>illegal value</source>
        <translation>wartość jest niedozwolona</translation>
    </message>
</context>
<context>
    <name>QImageReader</name>
    <message>
        <source>Unable to read image data</source>
        <translation>Nie można odczytać danych obrazu</translation>
    </message>
    <message>
        <source>Invalid device</source>
        <translation>Nieprawidłowe urządzenie</translation>
    </message>
    <message>
        <source>Unsupported image format</source>
        <translation>Nieobsługiwany format obrazu</translation>
    </message>
    <message>
        <source>File not found</source>
        <translation>Nie znaleziono pliku</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
</context>
<context>
    <name>QHttpSocketEngine</name>
    <message>
        <source>Proxy connection refused</source>
        <translation>Odmowa połączenia z serwerem proxy</translation>
    </message>
    <message>
        <source>Proxy denied connection</source>
        <translation>Odmowa połączenia z serwerem proxy</translation>
    </message>
    <message>
        <source>Proxy server not found</source>
        <translation>Nie znaleziono serwera proxy</translation>
    </message>
    <message>
        <source>Proxy server connection timed out</source>
        <translation>Upłynął limit czasu połączenia z serwerem proxy</translation>
    </message>
    <message>
        <source>Did not receive HTTP response from proxy</source>
        <translation>Nie otrzymano odpowiedzi HTTP z serwera proxy</translation>
    </message>
    <message>
        <source>Proxy connection closed prematurely</source>
        <translation>Połączenie z serwerem proxy zostało przedwcześnie zamknięte</translation>
    </message>
    <message>
        <source>Error communicating with HTTP proxy</source>
        <translation>Błąd komunikacji z serwerem proxy HTTP</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation>Wymagane uwierzytelnienie</translation>
    </message>
    <message>
        <source>Error parsing authentication request from proxy</source>
        <translation>Błąd podczas analizowania żądania uwierzytelnienia z serwera proxy</translation>
    </message>
</context>
<context>
    <name>QSaveFile</name>
    <message>
        <source>Filename refers to a directory</source>
        <translation>Nazwa pliku odnosi się do katalogu</translation>
    </message>
    <message>
        <source>Writing canceled by application</source>
        <translation>Zapisywanie anulowane przez aplikację</translation>
    </message>
    <message>
        <source>Existing file %1 is not writable</source>
        <translation>Istniejący plik %1 nie jest zapisywalny</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessManager</name>
    <message>
        <source>Network access is disabled.</source>
        <translation>Dostęp do sieci jest wyłączony.</translation>
    </message>
</context>
<context>
    <name>QNetworkReply</name>
    <message>
        <source>Error downloading %1 - server replied: %2</source>
        <translation>Wystąpił błąd podczas pobierania %1 — odpowiedział serwer: %2</translation>
    </message>
    <message>
        <source>Network session error.</source>
        <translation>Błąd sesji sieciowej.</translation>
    </message>
    <message>
        <source>Protocol &quot;%1&quot; is unknown</source>
        <translation>Protokół &quot;%1&quot; jest nieznany</translation>
    </message>
    <message>
        <source>backend start error.</source>
        <translation>błąd uruchamiania backendu.</translation>
    </message>
    <message>
        <source>Background request not allowed.</source>
        <translation>Żądanie w tle jest niedozwolone.</translation>
    </message>
    <message>
        <source>Temporary network failure.</source>
        <translation>Tymczasowa awaria sieci.</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>Step &amp;down</source>
        <translation>Krok &amp;w dół</translation>
    </message>
    <message>
        <source>&amp;Step up</source>
        <translation>&amp;Krok w górę</translation>
    </message>
    <message>
        <source>&amp;Select All</source>
        <translation>&amp;Zaznacz wszystko</translation>
    </message>
</context>
<context>
    <name>QDB2Result</name>
    <message>
        <source>Unable to bind variable</source>
        <translation>Nie można powiązać zmiennej</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Nie można wykonać instrukcji</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>Nie można pobrać następnego</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Nie można przygotować instrukcji</translation>
    </message>
    <message>
        <source>Unable to fetch record %1</source>
        <translation>Nie można pobrać rekordu %1</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>Nie można pobrać w pierwszej kolejności</translation>
    </message>
</context>
<context>
    <name>QODBCResult</name>
    <message>
        <source>Unable to bind variable</source>
        <translation>Nie można powiązać zmiennej</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Nie można wykonać instrukcji</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>Nie można pobrać następnego</translation>
    </message>
    <message>
        <source>Unable to fetch last</source>
        <translation>Nie można pobrać ostatniego</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Nie można przygotować instrukcji</translation>
    </message>
    <message>
        <source>Unable to fetch previous</source>
        <translation>Nie można pobrać poprzedniego</translation>
    </message>
    <message>
        <source>Unable to fetch</source>
        <translation>Nie można pobrać</translation>
    </message>
    <message>
        <source>QODBCResult::reset: Unable to set &apos;SQL_CURSOR_STATIC&apos; as statement attribute. Please check your ODBC driver configuration</source>
        <translation>QODBCResult::reset: Nie można ustawić atrybutu &quot;SQL_CURSOR_STATIC&quot; jako instrukcji. Sprawdź konfigurację sterownika ODBC</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>Nie można pobrać w pierwszej kolejności</translation>
    </message>
</context>
<context>
    <name>QPSQLDriver</name>
    <message>
        <source>Unable to subscribe</source>
        <translation>Nie można subskrybować</translation>
    </message>
    <message>
        <source>Could not begin transaction</source>
        <translation>Nie można rozpocząć transakcji</translation>
    </message>
    <message>
        <source>Could not rollback transaction</source>
        <translation>Nie można wycofać transakcji</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation>Nie można zatwierdzić transakcji</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>Nie można połączyć</translation>
    </message>
    <message>
        <source>Unable to unsubscribe</source>
        <translation>Nie można anulować subskrypcji</translation>
    </message>
</context>
<context>
    <name>QInputDialog</name>
    <message>
        <source>Enter a value:</source>
        <translation>Wpisz wartość:</translation>
    </message>
</context>
<context>
    <name>QCoreApplication</name>
    <message>
        <source>%1: key is empty</source>
        <translation>%1: klucz jest pusty</translation>
    </message>
    <message>
        <source>QT_LAYOUT_DIRECTION</source>
        <translation>QT_UKŁAD_KIERUNKU</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation>%1: nie można utworzyć klucza</translation>
    </message>
    <message>
        <source>%1: ftok failed</source>
        <translation>%1: błąd funkcji ftok</translation>
    </message>
</context>
<context>
    <name>QIODevice</name>
    <message>
        <source>No such file or directory</source>
        <translation>Brak takiego pliku lub katalogu</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Odmowa uprawnień</translation>
    </message>
    <message>
        <source>file to open is a directory</source>
        <translation>plik do otwarcia to katalog</translation>
    </message>
    <message>
        <source>No space left on device</source>
        <translation>Brak miejsca na dysku</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
    <message>
        <source>Too many open files</source>
        <translation>Zbyt wiele otwartych plików</translation>
    </message>
</context>
<context>
    <name>QTabBar</name>
    <message>
        <source>Scroll Left</source>
        <translation>Przewiń w lewo</translation>
    </message>
    <message>
        <source>Scroll Right</source>
        <translation>Przewiń w prawo</translation>
    </message>
</context>
<context>
    <name>QUndoModel</name>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;pusty&gt;</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessCacheBackend</name>
    <message>
        <source>Error opening %1</source>
        <translation>Błąd otwarcia %1</translation>
    </message>
</context>
<context>
    <name>QMYSQLResult</name>
    <message>
        <source>Unable to execute statement</source>
        <translation>Nie można wykonać instrukcji</translation>
    </message>
    <message>
        <source>Unable to store statement results</source>
        <translation>Nie można zapisać wyników instrukcji</translation>
    </message>
    <message>
        <source>Unable to execute next query</source>
        <translation>Nie można wykonać następnego zapytania</translation>
    </message>
    <message>
        <source>Unable to bind outvalues</source>
        <translation>Nie można powiązać wartości wychodzących</translation>
    </message>
    <message>
        <source>Unable to store next result</source>
        <translation>Nie można zapisać następnego wyniku</translation>
    </message>
    <message>
        <source>Unable to fetch data</source>
        <translation>Nie można pobrać danych</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Nie można przygotować instrukcji</translation>
    </message>
    <message>
        <source>Unable to store result</source>
        <translation>Nie można zapisać wyniku</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>Nie można powiązać wartości</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>Nie można wykonać zapytania</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>Nie można zresetować instrukcji</translation>
    </message>
</context>
<context>
    <name>QSQLite2Result</name>
    <message>
        <source>Unable to execute statement</source>
        <translation>Nie można wykonać instrukcji</translation>
    </message>
    <message>
        <source>Unable to fetch results</source>
        <translation>Nie można pobrać wyników</translation>
    </message>
</context>
<context>
    <name>QNetworkSessionPrivateImpl</name>
    <message>
        <source>The session was aborted by the user or system.</source>
        <translation>Sesja została przerwana przez użytkownika lub system.</translation>
    </message>
    <message>
        <source>The requested operation is not supported by the system.</source>
        <translation>Żądana operacja nie jest obsługiwana przez system.</translation>
    </message>
    <message>
        <source>Roaming was aborted or is not possible.</source>
        <translation>Roaming został przerwany lub nie jest możliwy.</translation>
    </message>
    <message>
        <source>The specified configuration cannot be used.</source>
        <translation>Nie można użyć określonej konfiguracji.</translation>
    </message>
    <message>
        <source>Unknown session error.</source>
        <translation>Nieznany błąd sesji.</translation>
    </message>
</context>
<context>
    <name>QWindowsDirect2DIntegration</name>
    <message>
        <source>Qt cannot load the direct2d platform plugin because the Direct2D version on this system is too old. The minimum system requirement for this platform plugin is Windows 7 SP1 with Platform Update.

The minimum Direct2D version required is %1.%2.%3.%4. The Direct2D version on this system is %5.%6.%7.%8.</source>
        <translation>Qt nie może załadować wtyczki platformy direct2d, ponieważ wersja Direct2D na tym systemie jest zbyt stara. Minimalne wymagania systemowe dla tej wtyczki platformy to Windows 7 SP1 z aktualizacją Platform Update.

Minimalna wymagana wersja Direct2D to %1.%2.%3.%4. Wersja Direct2D w tym systemie to %5.%6.%7.%8.</translation>
    </message>
    <message>
        <source>Cannot load direct2d platform plugin</source>
        <translation>Nie można załadować wtyczki platformy direct2d</translation>
    </message>
</context>
<context>
    <name>QLocalServer</name>
    <message>
        <source>%1: Name error</source>
        <translation>%1: Błąd nazwy</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: Nieznany błąd %2</translation>
    </message>
    <message>
        <source>%1: Permission denied</source>
        <translation>%1: Odmowa uprawnień</translation>
    </message>
    <message>
        <source>%1: Address in use</source>
        <translation>%1: Adres w użyciu</translation>
    </message>
</context>
<context>
    <name>QGuiApplication</name>
    <message>
        <source>QT_LAYOUT_DIRECTION</source>
        <translation>QT_UKŁAD_KIERUNKU</translation>
    </message>
</context>
<context>
    <name>QProgressDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
</context>
<context>
    <name>QImageWriter</name>
    <message>
        <source>Unsupported image format</source>
        <translation>Nieobsługiwany format obrazu</translation>
    </message>
    <message>
        <source>Device not writable</source>
        <translation>Nie można zapisać urządzenia</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
    <message>
        <source>Device is not set</source>
        <translation>Urządzenie nie jest ustawione</translation>
    </message>
</context>
<context>
    <name>MAC_APPLICATION_MENU</name>
    <message>
        <source>Hide Others</source>
        <translation>Ukryj inne</translation>
    </message>
    <message>
        <source>Quit %1</source>
        <translation>Zamknij %1</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>Info %1</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Preferencje...</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Serwis</translation>
    </message>
    <message>
        <source>Hide %1</source>
        <translation>Ukryj %1</translation>
    </message>
    <message>
        <source>Show All</source>
        <translation>Pokaż wszystko</translation>
    </message>
</context>
<context>
    <name>QTDSDriver</name>
    <message>
        <source>Unable to open connection</source>
        <translation>Nie można otworzyć połączenia</translation>
    </message>
    <message>
        <source>Unable to use database</source>
        <translation>Nie można użyć bazy danych</translation>
    </message>
</context>
<context>
    <name>QPrintPropertiesDialog</name>
    <message>
        <source>Job Options</source>
        <translation>Opcje pracy</translation>
    </message>
</context>
<context>
    <name>QPluginLoader</name>
    <message>
        <source>The plugin was not loaded.</source>
        <translation>Wtyczka nie została załadowana.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
</context>
<context>
    <name>QQnxFilePicker</name>
    <message>
        <source>Pick a file</source>
        <translation>Wybierz plik</translation>
    </message>
</context>
<context>
    <name>CloseButton</name>
    <message>
        <source>Close Tab</source>
        <translation>Закрыть вкладку</translation>
    </message>
</context>
<context>
    <name>QPSQLResult</name>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Nie można przygotować instrukcji</translation>
    </message>
    <message>
        <source>Unable to create query</source>
        <translation>Nie można utworzyć zapytania</translation>
    </message>
</context>
<context>
    <name>QFileDevice</name>
    <message>
        <source>No file engine available or engine does not support UnMapExtension</source>
        <translation>Brak dostępnego silnika plików lub silnik nie obsługuje UnMapExtension</translation>
    </message>
</context>
<context>
    <name>QNetworkSession</name>
    <message>
        <source>Invalid configuration.</source>
        <translation>Nieprawidłowa konfiguracja.</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDataBackend</name>
    <message>
        <source>Invalid URI: %1</source>
        <translation>Nieprawidłowy URI: %1</translation>
    </message>
</context>
<context>
    <name>QKeySequenceEdit</name>
    <message>
        <source>Press shortcut</source>
        <translation>Naciśnij skrót</translation>
    </message>
    <message>
        <source>%1, ...</source>
        <translation>%1, ...</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDebugPipeBackend</name>
    <message>
        <source>Socket error on %1: %2</source>
        <translation>Błąd gniazda na %1: %2</translation>
    </message>
    <message>
        <source>Remote host closed the connection prematurely on %1</source>
        <translation>Zdalny host przedwcześnie zamknął połączenie na %1</translation>
    </message>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Błąd zapisu do %1: %2</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFileBackend</name>
    <message>
        <source>Request for opening non-local file %1</source>
        <translation>Żądanie otwarcia nielokalnego pliku %1</translation>
    </message>
    <message>
        <source>Read error reading from %1: %2</source>
        <translation>Błąd odczytu z %1: %2</translation>
    </message>
    <message>
        <source>Cannot open %1: Path is a directory</source>
        <translation>Nie można otworzyć %1: Ścieżka to katalog</translation>
    </message>
    <message>
        <source>Error opening %1: %2</source>
        <translation>Błąd otwarcia %1: %2</translation>
    </message>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Błąd zapisu do %1: %2</translation>
    </message>
</context>
<context>
    <name>QHostInfo</name>
    <message>
        <source>No host name given</source>
        <translation>Nie podano nazwy hosta</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyImpl</name>
    <message>
        <source>Operation canceled</source>
        <translation>Operacja anulowana</translation>
    </message>
</context>
<context>
    <name>QStateMachine</name>
    <message>
        <source>Missing default state in history state &apos;%1&apos;</source>
        <translation>Brak stanu domyślnego w stanie historii &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
    <message>
        <source>Missing initial state in compound state &apos;%1&apos;</source>
        <translation>Brak stanu początkowego w stanie złożonym &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No common ancestor for targets and source of transition from state &apos;%1&apos;</source>
        <translation>Brak wspólnego elementu nadrzędnego dla celów i źródła przejścia ze stanu &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>QMdiArea</name>
    <message>
        <source>(Untitled)</source>
        <translation>(Bez tytułu)</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>Executable &apos;%1&apos; requires Qt %2, found Qt %3.</source>
        <translation>Plik wykonywalny &quot;%1&quot; wymaga Qt %2, znaleziono Qt %3.</translation>
    </message>
    <message>
        <source>Incompatible Qt Library Error</source>
        <translation>Błąd niezgodnej biblioteki Qt</translation>
    </message>
</context>
<context>
    <name>QCocoaTheme</name>
    <message>
        <source>Don&apos;t Save</source>
        <translation>Nie zapisuj</translation>
    </message>
</context>
<context>
    <name>QDnsLookup</name>
    <message>
        <source>Operation cancelled</source>
        <translation>Operacja anulowana</translation>
    </message>
</context>
<context>
    <name>QTcpServer</name>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>Operacja na gnieździe nie jest obsługiwana</translation>
    </message>
</context>
</TS>
